// AI盲人眼镜移动端应用
console.log('[APP] 开始加载应用...');

class AIGlassApp {
    constructor() {
        console.log('[APP] 构造函数被调用');
        // 状态管理
        this.state = {
            cameraActive: false,
            micActive: false,
            connected: false,
            recording: false,
            currentFacingMode: 'environment', // 'user' or 'environment'
            flashEnabled: false,
            navigationMode: null, // null, 'blindpath', 'crossing'
            gyroEnabled: false // 陀螺仪状态
        };

        // WebSocket连接
        this.ws = {
            camera: null,
            audio: null,
            ui: null,
            imu: null // IMU数据WebSocket
        };
        
        // 陀螺仪数据
        this.imuData = {
            alpha: 0,  // 绕Z轴旋转（指南针方向）
            beta: 0,   // 绕X轴旋转（前后倾斜）
            gamma: 0,  // 绕Y轴旋转（左右倾斜）
            accel: { x: 0, y: 0, z: 0 },
            gyro: { x: 0, y: 0, z: 0 }
        };

        // 媒体流
        this.mediaStream = null;
        this.audioContext = null;
        this.audioProcessor = null;

    // 绑定引用（用于 add/removeEventListener）
    this.boundHandleOrientation = null;
    this.boundHandleMotion = null;
    this.imuInterval = null;

        // DOM元素
        this.elements = {};
        
        // 初始化
        this.init();
    }

    init() {
        console.log('[APP] init() 被调用, readyState:', document.readyState);
        // 等待DOM加载完成
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => {
                console.log('[APP] DOMContentLoaded 事件触发');
                this.setup();
            });
        } else {
            this.setup();
        }
    }

    setup() {
        console.log('[APP] setup() 开始执行');
        
        try {
            // 获取DOM元素
            this.cacheElements();
            console.log('[APP] DOM元素缓存完成');
            
            // 绑定事件
            this.bindEvents();
            console.log('[APP] 事件绑定完成');
            
            // 加载保存的服务器地址
            this.loadServerConfig();
            console.log('[APP] 服务器配置加载完成');
            
            // 显示欢迎提示
            this.showToast('欢迎使用AI盲人眼镜系统');
            console.log('[APP] 应用初始化完成');
        } catch (error) {
            console.error('[APP] 初始化失败:', error);
            alert('应用初始化失败: ' + error.message);
        }
    }

    cacheElements() {
        // 状态栏 - 新的点状指示器
        this.elements.cameraStatusDot = document.getElementById('cameraStatusDot');
        this.elements.micStatusDot = document.getElementById('micStatusDot');
        this.elements.connectionStatusDot = document.getElementById('connectionStatusDot');

        // 视频
        this.elements.localVideo = document.getElementById('localVideo');
        this.elements.videoCanvas = document.getElementById('videoCanvas');
        this.elements.switchCameraBtn = document.getElementById('switchCameraBtn');
        this.elements.toggleFlashBtn = document.getElementById('toggleFlashBtn');

        // 语音识别
        this.elements.recordingIndicator = document.getElementById('recordingIndicator');
        this.elements.partialText = document.getElementById('partialText');
        this.elements.voiceRecognition = document.getElementById('voiceRecognition');

        // 对话 - 新的滚动窗口
        this.elements.chatOverlay = document.getElementById('chatOverlay');
        this.elements.chatScroll = document.getElementById('chatScroll');

        // 控制按钮
        this.elements.startCameraBtn = document.getElementById('startCameraBtn');
        this.elements.startMicBtn = document.getElementById('startMicBtn');
        this.elements.startNavBtn = document.getElementById('startNavBtn');
        this.elements.startCrossBtn = document.getElementById('startCrossBtn');

        // 服务器配置
        this.elements.serverInput = document.getElementById('serverInput');
        this.elements.connectBtn = document.getElementById('connectBtn');
        this.elements.serverStatus = document.getElementById('serverStatus');
        this.elements.serverModal = document.getElementById('serverModal');
        this.elements.cancelConnectBtn = document.getElementById('cancelConnectBtn');
        this.elements.confirmConnectBtn = document.getElementById('confirmConnectBtn');

        // 其他
        this.elements.audioPlayer = document.getElementById('audioPlayer');
        this.elements.loadingOverlay = document.getElementById('loadingOverlay');
        this.elements.toast = document.getElementById('toast');
    }

    bindEvents() {
        console.log('[APP] 开始绑定事件...');
        
        // 摄像头控制
        if (this.elements.startCameraBtn) {
            this.elements.startCameraBtn.addEventListener('click', () => {
                console.log('[EVENT] 摄像头按钮被点击');
                this.toggleCamera();
            });
            console.log('[APP] 摄像头按钮事件已绑定');
        }
        
        if (this.elements.switchCameraBtn) {
            this.elements.switchCameraBtn.addEventListener('click', () => {
                console.log('[EVENT] 切换摄像头按钮被点击');
                this.switchCamera();
            });
        }
        
        if (this.elements.toggleFlashBtn) {
            this.elements.toggleFlashBtn.addEventListener('click', () => {
                console.log('[EVENT] 闪光灯按钮被点击');
                this.toggleFlash();
            });
        }

        // 麦克风控制
        if (this.elements.startMicBtn) {
            this.elements.startMicBtn.addEventListener('click', () => {
                console.log('[EVENT] 麦克风按钮被点击');
                this.toggleMicrophone();
            });
            console.log('[APP] 麦克风按钮事件已绑定');
        }

        // 导航控制 - 独立切换
        if (this.elements.startNavBtn) {
            this.elements.startNavBtn.addEventListener('click', () => {
                console.log('[EVENT] 盲道导航按钮被点击');
                this.toggleNavigation('blindpath');
            });
        }
        
        if (this.elements.startCrossBtn) {
            this.elements.startCrossBtn.addEventListener('click', () => {
                console.log('[EVENT] 过马路按钮被点击');
                this.toggleNavigation('crossing');
            });
        }

        // 服务器连接
        if (this.elements.connectBtn) {
            this.elements.connectBtn.addEventListener('click', () => {
                console.log('[EVENT] 连接按钮被点击');
                this.showServerModal();
            });
            console.log('[APP] 连接按钮事件已绑定');
        }
        
        if (this.elements.cancelConnectBtn) {
            this.elements.cancelConnectBtn.addEventListener('click', () => {
                this.hideServerModal();
            });
        }
        
        if (this.elements.confirmConnectBtn) {
            this.elements.confirmConnectBtn.addEventListener('click', () => {
                this.hideServerModal();
                this.connectToServer();
            });
        }

        // 防止页面滚动
        document.body.addEventListener('touchmove', (e) => {
            if (e.target === document.body) {
                e.preventDefault();
            }
        }, { passive: false });
        
        console.log('[APP] 所有事件绑定完成');
    }

    // ========== 摄像头功能 ==========
    async toggleCamera() {
        if (this.state.cameraActive) {
            await this.stopCamera();
        } else {
            await this.startCamera();
        }
    }

    async startCamera() {
        try {
            this.showLoading('正在启动摄像头...');

            const constraints = {
                video: {
                    facingMode: this.state.currentFacingMode,
                    width: { ideal: 1280 },
                    height: { ideal: 720 },
                    frameRate: { ideal: 30 }
                },
                audio: false
            };

            this.mediaStream = await navigator.mediaDevices.getUserMedia(constraints);
            this.elements.localVideo.srcObject = this.mediaStream;
            
            // iOS 需要显式播放视频
            try {
                await this.elements.localVideo.play();
            } catch (playError) {
                console.warn('[摄像头] 自动播放失败，等待用户交互:', playError);
            }

            this.state.cameraActive = true;
            this.updateCameraStatus(true);
            this.elements.startCameraBtn.classList.add('active');

            this.showToast('摄像头已启动');
            this.hideLoading();

            // 开始发送视频帧
            if (this.state.connected) {
                this.startSendingFrames();
            }

        } catch (error) {
            console.error('[摄像头] 启动失败:', error);
            let errorMsg = '无法访问摄像头';
            if (error.name === 'NotAllowedError') {
                errorMsg = '摄像头权限被拒绝，请在设置中允许';
            } else if (error.name === 'NotFoundError') {
                errorMsg = '未找到摄像头设备';
            } else if (error.name === 'NotReadableError') {
                errorMsg = '摄像头被其他应用占用';
            }
            this.showToast(errorMsg);
            this.hideLoading();
        }
    }

    async stopCamera() {
        if (this.mediaStream) {
            this.mediaStream.getTracks().forEach(track => track.stop());
            this.mediaStream = null;
        }

        this.elements.localVideo.srcObject = null;
        this.state.cameraActive = false;
        this.updateCameraStatus(false);
        this.elements.startCameraBtn.classList.remove('active');

        this.showToast('摄像头已关闭');
    }

    async switchCamera() {
        if (!this.state.cameraActive) {
            this.showToast('请先启动摄像头');
            return;
        }

        this.state.currentFacingMode = this.state.currentFacingMode === 'environment' ? 'user' : 'environment';
        
        await this.stopCamera();
        await this.startCamera();
        
        this.showToast(this.state.currentFacingMode === 'environment' ? '切换到后置摄像头' : '切换到前置摄像头');
    }

    async toggleFlash() {
        if (!this.state.cameraActive) {
            this.showToast('请先启动摄像头');
            return;
        }

        try {
            const track = this.mediaStream.getVideoTracks()[0];
            const capabilities = track.getCapabilities();

            if (capabilities.torch) {
                this.state.flashEnabled = !this.state.flashEnabled;
                await track.applyConstraints({
                    advanced: [{ torch: this.state.flashEnabled }]
                });
                this.showToast(this.state.flashEnabled ? '闪光灯已开启' : '闪光灯已关闭');
            } else {
                this.showToast('当前设备不支持闪光灯');
            }
        } catch (error) {
            console.error('切换闪光灯失败:', error);
            this.showToast('闪光灯控制失败');
        }
    }

    startSendingFrames() {
        if (!this.ws.camera || this.ws.camera.readyState !== WebSocket.OPEN) {
            console.warn('[视频帧] WebSocket未连接');
            return;
        }

        const canvas = this.elements.videoCanvas;
        const video = this.elements.localVideo;
        const ctx = canvas.getContext('2d');

        const sendFrame = () => {
            if (!this.state.cameraActive || !this.state.connected) {
                return;
            }

            // 检查视频是否准备好
            if (video.readyState < 2) {
                setTimeout(sendFrame, 100);
                return;
            }

            // 设置canvas尺寸
            if (canvas.width !== video.videoWidth || canvas.height !== video.videoHeight) {
                canvas.width = video.videoWidth;
                canvas.height = video.videoHeight;
            }

            // 绘制当前帧
            try {
                ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

                // 转换为JPEG并发送
                canvas.toBlob((blob) => {
                    if (blob && this.ws.camera && this.ws.camera.readyState === WebSocket.OPEN) {
                        this.ws.camera.send(blob);
                    }
                }, 'image/jpeg', 0.8);
            } catch (error) {
                console.error('[视频帧] 处理错误:', error);
            }

            // 30fps
            setTimeout(sendFrame, 33);
        };

        sendFrame();
    }

    // ========== 麦克风功能 ==========
    async toggleMicrophone() {
        if (this.state.micActive) {
            await this.stopMicrophone();
        } else {
            await this.startMicrophone();
        }
    }

    async startMicrophone() {
        try {
            this.showLoading('正在启动麦克风...');

            const stream = await navigator.mediaDevices.getUserMedia({
                audio: {
                    echoCancellation: true,
                    noiseSuppression: true,
                    autoGainControl: true,
                    sampleRate: 16000
                }
            });

            // 创建音频处理器 - iOS 需要用户交互后才能创建 AudioContext
            const AudioContextClass = window.AudioContext || window.webkitAudioContext;
            if (!this.audioContext) {
                this.audioContext = new AudioContextClass({ sampleRate: 16000 });
            }
            
            // iOS Safari 需要 resume AudioContext
            if (this.audioContext.state === 'suspended') {
                await this.audioContext.resume();
            }
            
            const source = this.audioContext.createMediaStreamSource(stream);
            
            // 创建ScriptProcessor处理音频数据
            const bufferSize = 4096;
            this.audioProcessor = this.audioContext.createScriptProcessor(bufferSize, 1, 1);
            
            this.audioProcessor.onaudioprocess = (e) => {
                if (!this.state.recording) {
                    // 添加调试日志
                    if (Math.random() < 0.01) { // 1% 概率输出，避免刷屏
                        console.log('[音频处理] 等待录音开始...');
                    }
                    return;
                }

                const inputData = e.inputBuffer.getChannelData(0);
                // 转换为16位PCM
                const pcm16 = this.floatTo16BitPCM(inputData);
                
                // 发送音频数据
                if (this.ws.audio && this.ws.audio.readyState === WebSocket.OPEN) {
                    this.ws.audio.send(pcm16);
                    // 添加调试日志
                    if (Math.random() < 0.001) { // 0.1% 概率输出
                        console.log('[音频处理] 正在发送音频数据, 大小:', pcm16.byteLength);
                    }
                } else {
                    console.warn('[音频处理] WebSocket 未连接');
                }
            };

            source.connect(this.audioProcessor);
            this.audioProcessor.connect(this.audioContext.destination);

            this.state.micActive = true;
            this.updateMicStatus(true);
            this.elements.startMicBtn.classList.add('active');

            this.showToast('麦克风已启动');
            this.hideLoading();

            // 如果已连接，开始录音
            if (this.state.connected && this.ws.audio) {
                this.startRecording();
            }

        } catch (error) {
            console.error('[麦克风] 启动失败:', error);
            let errorMsg = '无法访问麦克风';
            if (error.name === 'NotAllowedError') {
                errorMsg = '麦克风权限被拒绝，请在设置中允许';
            } else if (error.name === 'NotFoundError') {
                errorMsg = '未找到麦克风设备';
            } else if (error.name === 'NotReadableError') {
                errorMsg = '麦克风被其他应用占用';
            }
            this.showToast(errorMsg);
            this.hideLoading();
        }
    }

    async stopMicrophone() {
        if (this.audioProcessor) {
            this.audioProcessor.disconnect();
            this.audioProcessor = null;
        }

        if (this.audioContext) {
            await this.audioContext.close();
            this.audioContext = null;
        }

        this.state.micActive = false;
        this.state.recording = false;
        this.updateMicStatus(false);
        this.updateRecordingIndicator(false);
        this.elements.startMicBtn.classList.remove('active');

        this.showToast('麦克风已关闭');
    }

    floatTo16BitPCM(float32Array) {
        const buffer = new ArrayBuffer(float32Array.length * 2);
        const view = new DataView(buffer);
        let offset = 0;
        for (let i = 0; i < float32Array.length; i++, offset += 2) {
            let s = Math.max(-1, Math.min(1, float32Array[i]));
            view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
        }
        return buffer;
    }

    startRecording() {
        if (!this.ws.audio || this.ws.audio.readyState !== WebSocket.OPEN) {
            console.warn('[录音] WebSocket 未连接，无法开始录音');
            return;
        }

        console.log('[录音] 发送 START 命令到服务器');
        this.ws.audio.send('START');
        this.state.recording = true;
        this.updateRecordingIndicator(true);
        console.log('[录音] 录音已开始，状态:', this.state.recording);
        this.showToast('开始录音');
    }

    stopRecording() {
        if (!this.ws.audio || this.ws.audio.readyState !== WebSocket.OPEN) {
            return;
        }

        this.ws.audio.send('STOP');
        this.state.recording = false;
        this.updateRecordingIndicator(false);
    }

    // ========== WebSocket连接 ==========
    async connectToServer() {
        let serverAddr = this.elements.serverInput.value.trim();
        
        if (!serverAddr) {
            this.showToast('请输入服务器地址');
            return;
        }

        // 允许用户输入带协议的地址（http:// 或 https:// 或 ws:// / wss://），去掉多余前缀
        serverAddr = serverAddr.replace(/^https?:\/\//i, '').replace(/^wss?:\/\//i, '').replace(/\/$/, '');

        // 保存服务器地址
        localStorage.setItem('serverAddress', serverAddr);

        this.showLoading('正在连接服务器...');

        // 根据当前页面协议选择尝试顺序：优先使用与页面一致的 ws/wss，否则回退
        const tryProtocols = (window.location.protocol === 'https:') ? ['wss:', 'ws:'] : ['ws:', 'wss:'];
        let connected = false;
        let lastErr = null;

        for (const proto of tryProtocols) {
            const baseUrl = `${proto}//${serverAddr}`;
            console.log('[连接] 尝试连接到:', baseUrl);
            try {
                // 关闭之前可能存在的未完全关闭的 sockets
                try { this.ws.camera && this.ws.camera.close(); } catch(e){ }
                try { this.ws.audio && this.ws.audio.close(); } catch(e){ }
                try { this.ws.ui && this.ws.ui.close(); } catch(e){ }
                try { this.ws.imu && this.ws.imu.close(); } catch(e){ }

                await this.connectCameraWS(baseUrl);
                await this.connectAudioWS(baseUrl);
                await this.connectUIWS(baseUrl);

                try {
                    await this.connectIMUWS(baseUrl);
                } catch (error) {
                    console.warn('[IMU] 连接失败，继续运行:', error);
                }

                connected = true;
                // 成功则中断尝试
                break;
            } catch (error) {
                console.warn('[连接] 使用', proto, '失败:', error && error.message ? error.message : error);
                lastErr = error;
                // 清理并尝试下一个协议
                try { this.ws.camera && this.ws.camera.close(); } catch(e){ }
                try { this.ws.audio && this.ws.audio.close(); } catch(e){ }
                try { this.ws.ui && this.ws.ui.close(); } catch(e){ }
                try { this.ws.imu && this.ws.imu.close(); } catch(e){ }
                continue;
            }
        }

        if (!connected) {
            console.error('连接服务器失败:', lastErr);
            this.showToast('连接失败: ' + (lastErr && lastErr.message ? lastErr.message : '请检查地址与网络'));
            this.hideLoading();
            return;
        }

        this.state.connected = true;
        this.updateConnectionStatus(true);
        this.elements.connectBtn.classList.add('connected');
        this.elements.serverStatus.textContent = '已连接';

        this.showToast('服务器连接成功');
        this.hideLoading();

        // 如果摄像头已启动，开始发送帧
        if (this.state.cameraActive) {
            this.startSendingFrames();
        }

        // 如果麦克风已启动，开始录音
        if (this.state.micActive) {
            this.startRecording();
        }

        // 启动陀螺仪（会在需要时弹出权限请求）
        this.startGyroscope();
    }

    connectCameraWS(baseUrl) {
        return new Promise((resolve, reject) => {
            const wsUrl = `${baseUrl}/ws/camera`;
            console.log('[摄像头WS] 连接到:', wsUrl);
            
            this.ws.camera = new WebSocket(wsUrl);
            
            // 设置超时
            const timeout = setTimeout(() => {
                if (this.ws.camera.readyState !== WebSocket.OPEN) {
                    this.ws.camera.close();
                    reject(new Error('摄像头连接超时'));
                }
            }, 10000);
            
            this.ws.camera.onopen = () => {
                clearTimeout(timeout);
                console.log('[摄像头WS] 已连接');
                resolve();
            };

            this.ws.camera.onerror = (error) => {
                clearTimeout(timeout);
                console.error('[摄像头WS] 错误:', error);
                reject(new Error('摄像头连接失败'));
            };

            this.ws.camera.onclose = () => {
                console.log('[摄像头WS] 已断开');
                this.handleDisconnect();
            };
        });
    }

    connectAudioWS(baseUrl) {
        return new Promise((resolve, reject) => {
            const wsUrl = `${baseUrl}/ws_audio`;
            console.log('[音频WS] 连接到:', wsUrl);
            
            this.ws.audio = new WebSocket(wsUrl);
            
            // 设置超时
            const timeout = setTimeout(() => {
                if (this.ws.audio.readyState !== WebSocket.OPEN) {
                    this.ws.audio.close();
                    reject(new Error('音频连接超时'));
                }
            }, 10000);
            
            this.ws.audio.onopen = () => {
                clearTimeout(timeout);
                console.log('[音频WS] 已连接');
                resolve();
            };

            this.ws.audio.onerror = (error) => {
                clearTimeout(timeout);
                console.error('[音频WS] 错误:', error);
                reject(new Error('音频连接失败'));
            };

            this.ws.audio.onclose = () => {
                console.log('[音频WS] 已断开');
            };

            this.ws.audio.onmessage = (event) => {
                // 处理服务器响应
                console.log('[音频WS] 收到消息:', event.data);
                
                // 如果收到 OK:STARTED，确认录音已开始
                if (event.data === 'OK:STARTED') {
                    console.log('[音频WS] 服务器确认录音已开始');
                    this.showToast('服务器已开始接收音频');
                }
            };
        });
    }

    connectUIWS(baseUrl) {
        return new Promise((resolve, reject) => {
            const wsUrl = `${baseUrl}/ws_ui`;
            console.log('[UI WS] 连接到:', wsUrl);
            
            this.ws.ui = new WebSocket(wsUrl);
            
            // 设置超时
            const timeout = setTimeout(() => {
                if (this.ws.ui.readyState !== WebSocket.OPEN) {
                    this.ws.ui.close();
                    reject(new Error('UI连接超时'));
                }
            }, 10000);
            
            this.ws.ui.onopen = () => {
                clearTimeout(timeout);
                console.log('[UI WS] 已连接');
                resolve();
            };

            this.ws.ui.onerror = (error) => {
                clearTimeout(timeout);
                console.error('[UI WS] 错误:', error);
                reject(new Error('UI连接失败'));
            };

            this.ws.ui.onclose = () => {
                console.log('[UI WS] 已断开');
            };

            this.ws.ui.onmessage = (event) => {
                this.handleUIMessage(event.data);
            };
        });
    }
    
    connectIMUWS(baseUrl) {
        return new Promise((resolve, reject) => {
            const wsUrl = `${baseUrl}/ws`;
            console.log('[IMU WS] 连接到:', wsUrl);
            
            this.ws.imu = new WebSocket(wsUrl);
            
            const timeout = setTimeout(() => {
                if (this.ws.imu.readyState !== WebSocket.OPEN) {
                    this.ws.imu.close();
                    // IMU连接失败不影响主流程
                    console.warn('[IMU WS] 连接超时，继续运行');
                    resolve();
                }
            }, 5000);
            
            this.ws.imu.onopen = () => {
                clearTimeout(timeout);
                console.log('[IMU WS] 已连接');
                resolve();
            };

            this.ws.imu.onerror = (error) => {
                clearTimeout(timeout);
                console.warn('[IMU WS] 连接失败:', error);
                // 不阻塞主流程
                resolve();
            };

            this.ws.imu.onclose = () => {
                console.log('[IMU WS] 已断开');
            };
        });
    }

    handleUIMessage(message) {
        try {
            console.log('[UI消息] 收到:', message.substring(0, 100)); // 只显示前100个字符
            
            if (message.startsWith('INIT:')) {
                const data = JSON.parse(message.slice(5));
                this.elements.partialText.textContent = data.partial || '等待语音输入...';
                console.log('[UI消息] INIT 数据:', data);
                
                // 加载历史消息
                if (data.finals && data.finals.length > 0) {
                    console.log('[UI消息] 加载历史消息:', data.finals.length, '条');
                    data.finals.forEach(text => {
                        this.addMessage(text);
                    });
                }
            } else if (message.startsWith('PARTIAL:')) {
                const partialText = message.slice(8);
                this.elements.partialText.textContent = partialText;
                console.log('[UI消息] 部分识别:', partialText);
            } else if (message.startsWith('FINAL:')) {
                const text = message.slice(6);
                console.log('[UI消息] 最终识别:', text);
                this.addMessage(text);
                this.elements.partialText.textContent = '等待语音输入...';
                // 显示提示
                this.showToast('识别: ' + text.substring(0, 20));
            } else if (message.startsWith('AUDIO:')) {
                // 处理音频播放
                const audioData = message.slice(6);
                console.log('[UI消息] 收到音频数据，长度:', audioData.length);
                this.playAudio(audioData);
            } else {
                console.log('[UI消息] 未知消息类型:', message.substring(0, 50));
            }
        } catch (error) {
            console.error('[UI消息] 处理错误:', error, '消息:', message.substring(0, 100));
        }
    }
    
    playAudio(audioData) {
        try {
            // 播放base64编码的音频
            const audio = this.elements.audioPlayer;
            audio.src = `data:audio/wav;base64,${audioData}`;
            audio.play().catch(err => {
                console.error('[音频播放] 失败:', err);
            });
        } catch (error) {
            console.error('[音频播放] 错误:', error);
        }
    }

    handleDisconnect() {
        this.state.connected = false;
        this.updateConnectionStatus(false);
        this.elements.connectBtn.classList.remove('connected');
        this.elements.serverStatus.textContent = '未连接';
        this.showToast('服务器连接已断开');
        
        // 停止陀螺仪
        this.stopGyroscope();
    }
    
    // ========== 陀螺仪功能 ==========
    startGyroscope() {
        if (this.state.gyroEnabled) {
            return;
        }
        
        console.log('[陀螺仪] 尝试启动...');
        
        // 请求设备方向权限（iOS 13+需要）
        if (typeof DeviceOrientationEvent !== 'undefined' && typeof DeviceOrientationEvent.requestPermission === 'function') {
            DeviceOrientationEvent.requestPermission()
                .then(permissionState => {
                    if (permissionState === 'granted') {
                        this.initGyroscope();
                    } else {
                        console.warn('[陀螺仪] 权限被拒绝');
                        this.showToast('陀螺仪权限被拒绝');
                    }
                })
                .catch(error => {
                    console.error('[陀螺仪] 权限请求失败:', error);
                });
        } else {
            // 非iOS或旧版本，直接启动
            this.initGyroscope();
        }
    }
    
    initGyroscope() {
        // 使用持久化的绑定引用，便于后续移除监听器
        this.boundHandleOrientation = this.handleOrientation.bind(this);
        this.boundHandleMotion = this.handleMotion.bind(this);

        // 监听设备方向事件
        window.addEventListener('deviceorientation', this.boundHandleOrientation, true);
        
        // 监听设备运动事件（加速度和陀螺仪）
        window.addEventListener('devicemotion', this.boundHandleMotion, true);

        this.state.gyroEnabled = true;
        console.log('[陀螺仪] 已启动');
        this.showToast('陀螺仪已启动');

        // 开始发送IMU数据
        this.startSendingIMU();
    }
    
    stopGyroscope() {
        if (!this.state.gyroEnabled) {
            return;
        }
        // 使用之前保存的绑定引用来移除监听器
        try {
            if (this.boundHandleOrientation) {
                window.removeEventListener('deviceorientation', this.boundHandleOrientation, true);
            }
            if (this.boundHandleMotion) {
                window.removeEventListener('devicemotion', this.boundHandleMotion, true);
            }
        } catch (e) {
            console.warn('[陀螺仪] 移除监听器时出错:', e);
        }

        // 清理定时器
        if (this.imuInterval) {
            clearInterval(this.imuInterval);
            this.imuInterval = null;
        }

        this.state.gyroEnabled = false;
        console.log('[陀螺仪] 已停止');
    }
    
    handleOrientation(event) {
        // 设备方向数据
        this.imuData.alpha = event.alpha || 0;  // 0-360度，指南针方向
        this.imuData.beta = event.beta || 0;    // -180到180度，前后倾斜
        this.imuData.gamma = event.gamma || 0;  // -90到90度，左右倾斜
    }
    
    handleMotion(event) {
        // 加速度数据（包含重力）
        if (event.accelerationIncludingGravity) {
            this.imuData.accel.x = event.accelerationIncludingGravity.x || 0;
            this.imuData.accel.y = event.accelerationIncludingGravity.y || 0;
            this.imuData.accel.z = event.accelerationIncludingGravity.z || 0;
        }
        
        // 陀螺仪数据（角速度）
        if (event.rotationRate) {
            this.imuData.gyro.x = event.rotationRate.alpha || 0;
            this.imuData.gyro.y = event.rotationRate.beta || 0;
            this.imuData.gyro.z = event.rotationRate.gamma || 0;
        }
    }
    
    startSendingIMU() {
        // 每100ms发送一次IMU数据
        this.imuInterval = setInterval(() => {
            if (!this.state.gyroEnabled || !this.state.connected) {
                return;
            }

            if (this.ws.imu && this.ws.imu.readyState === WebSocket.OPEN) {
                const imuPacket = {
                    ts: Date.now(),
                    accel: {
                        x: this.imuData.accel.x,
                        y: this.imuData.accel.y,
                        z: this.imuData.accel.z
                    },
                    gyro: {
                        x: this.imuData.gyro.x,
                        y: this.imuData.gyro.y,
                        z: this.imuData.gyro.z
                    },
                    orientation: {
                        alpha: this.imuData.alpha,
                        beta: this.imuData.beta,
                        gamma: this.imuData.gamma
                    }
                };

                try {
                    this.ws.imu.send(JSON.stringify(imuPacket));
                    // 每秒输出一次确认信息（1%概率）
                    if (Math.random() < 0.01) {
                        console.log('[IMU] ✓ 陀螺仪数据发送成功:', {
                            方向: `α:${this.imuData.alpha.toFixed(1)}° β:${this.imuData.beta.toFixed(1)}° γ:${this.imuData.gamma.toFixed(1)}°`,
                            加速度: `x:${this.imuData.accel.x.toFixed(2)} y:${this.imuData.accel.y.toFixed(2)} z:${this.imuData.accel.z.toFixed(2)}`
                        });
                    }
                } catch (error) {
                    console.error('[IMU] 发送数据失败:', error);
                }
            }
        }, 100);
    }
    // ========== 导航功能 - 独立切换 ==========
    toggleNavigation(mode) {
        if (!this.state.connected) {
            this.showToast('请先连接服务器');
            return;
        }

        if (!this.ws.audio || this.ws.audio.readyState !== WebSocket.OPEN) {
            this.showToast('音频连接未就绪');
            return;
        }

        // 检查当前模式是否已激活
        const isActive = mode === 'blindpath'
            ? this.elements.startNavBtn.classList.contains('active')
            : this.elements.startCrossBtn.classList.contains('active');

        if (isActive) {
            // 如果已激活，则停止
            const command = mode === 'blindpath' ? '停止导航' : '过马路结束';
            console.log('[导航] 发送停止命令:', command);
            this.ws.audio.send(`PROMPT:${command}`);
            
            if (mode === 'blindpath') {
                this.elements.startNavBtn.classList.remove('active');
            } else {
                this.elements.startCrossBtn.classList.remove('active');
            }
            
            this.showToast(mode === 'blindpath' ? '盲道导航已停止' : '过马路模式已停止');
        } else {
            // 如果未激活，则启动
            const command = mode === 'blindpath' ? '开始导航' : '开始过马路';
            console.log('[导航] 发送启动命令:', command);
            this.ws.audio.send(`PROMPT:${command}`);
            
            if (mode === 'blindpath') {
                this.elements.startNavBtn.classList.add('active');
            } else {
                this.elements.startCrossBtn.classList.add('active');
            }
            
            this.showToast(mode === 'blindpath' ? '盲道导航已启动' : '过马路模式已启动');
        }
    }

    // ========== UI更新 ==========
    updateCameraStatus(active) {
        if (active) {
            this.elements.cameraStatusDot.classList.add('active');
        } else {
            this.elements.cameraStatusDot.classList.remove('active');
        }
    }

    updateMicStatus(active) {
        if (active) {
            this.elements.micStatusDot.classList.add('active');
        } else {
            this.elements.micStatusDot.classList.remove('active');
        }
    }

    updateConnectionStatus(connected) {
        if (connected) {
            this.elements.connectionStatusDot.classList.add('active');
        } else {
            this.elements.connectionStatusDot.classList.remove('active');
        }
    }

    updateRecordingIndicator(recording) {
        if (recording) {
            this.elements.recordingIndicator.classList.add('recording');
        } else {
            this.elements.recordingIndicator.classList.remove('recording');
        }
    }

    addMessage(text) {
        console.log('[消息] 添加消息:', text);
        
        const isUser = !text.startsWith('[AI]') && !text.startsWith('[导航]') && !text.startsWith('[系统]');
        const cleanText = text.replace(/^\[(AI|导航|系统)\]\s*/, '');

        const messageDiv = document.createElement('div');
        messageDiv.className = `chat-message ${isUser ? 'user' : 'ai'}`;
        messageDiv.textContent = cleanText;

        this.elements.chatScroll.appendChild(messageDiv);
        
        // 保持最多显示10条消息
        const messages = this.elements.chatScroll.querySelectorAll('.chat-message');
        if (messages.length > 10) {
            messages[0].remove();
        }
        
        // 自动滚动到底部
        this.elements.chatOverlay.scrollTop = this.elements.chatOverlay.scrollHeight;
        
        console.log('[消息] 消息已添加到界面');
        
        // 如果是 AI 或系统消息，使用 TTS 播放
        if (!isUser && cleanText) {
            this.speakText(cleanText);
        }
    }
    
    speakText(text) {
        try {
            // 使用浏览器的 Web Speech API 进行文字转语音
            if ('speechSynthesis' in window) {
                // 停止当前正在播放的语音
                window.speechSynthesis.cancel();
                
                const utterance = new SpeechSynthesisUtterance(text);
                utterance.lang = 'zh-CN'; // 中文
                utterance.rate = 1.0; // 语速
                utterance.pitch = 1.0; // 音调
                utterance.volume = 1.0; // 音量
                
                utterance.onstart = () => {
                    console.log('[TTS] 开始播放:', text.substring(0, 20));
                };
                
                utterance.onend = () => {
                    console.log('[TTS] 播放完成');
                };
                
                utterance.onerror = (event) => {
                    console.error('[TTS] 播放错误:', event.error);
                };
                
                window.speechSynthesis.speak(utterance);
            } else {
                console.warn('[TTS] 浏览器不支持语音合成');
            }
        } catch (error) {
            console.error('[TTS] 语音播放失败:', error);
        }
    }
    
    // ========== 服务器连接弹窗 ==========
    showServerModal() {
        this.elements.serverModal.style.display = 'flex';
    }
    
    hideServerModal() {
        this.elements.serverModal.style.display = 'none';
    }

    // ========== 工具函数 ==========
    showLoading(text = '加载中...') {
        this.elements.loadingOverlay.querySelector('.loading-text').textContent = text;
        this.elements.loadingOverlay.style.display = 'flex';
    }

    hideLoading() {
        this.elements.loadingOverlay.style.display = 'none';
    }

    showToast(message, duration = 2000) {
        this.elements.toast.textContent = message;
        this.elements.toast.classList.add('show');
        
        setTimeout(() => {
            this.elements.toast.classList.remove('show');
        }, duration);
    }

    loadServerConfig() {
        const savedAddress = localStorage.getItem('serverAddress');
        if (savedAddress) {
            this.elements.serverInput.value = savedAddress;
        } else {
            // 尝试自动检测局域网地址
            const hostname = window.location.hostname;
            if (hostname !== 'localhost' && hostname !== '127.0.0.1') {
                this.elements.serverInput.value = `${hostname}:8081`;
            }
        }
    }
}

// 初始化应用
const app = new AIGlassApp();