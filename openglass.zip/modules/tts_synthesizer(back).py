import pyttsx3
import sys
import os
import tempfile
import base64
import time

def text_to_wav(text: str):
    """
    将文本转换为WAV音频数据，并将Base64编码结果打印到stdout。
    在一个独立的进程中运行，以确保环境纯净。
    """
    engine = None
    tmp_path = None
    try:
        # 1. 初始化TTS引擎（使用espeak驱动）
        engine = pyttsx3.init(driverName='espeak')
        
        # 2. 设置基本属性（不尝试切换语音）
        try:
            engine.setProperty('rate', 150)
            engine.setProperty('volume', 0.9)
            print(f"[TTS] 使用espeak默认配置", file=sys.stderr)
        except Exception as e:
            print(f"[TTS] 属性设置失败: {e}", file=sys.stderr)

        # 3. 创建唯一的临时文件
        with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as tmp_file:
            tmp_path = tmp_file.name

        # 4. 保存到文件并等待完成
        engine.save_to_file(text, tmp_path)
        engine.runAndWait()
        engine.stop()

        # 5. 等待文件系统同步
        time.sleep(0.1)

        # 6. 读取文件内容
        if os.path.exists(tmp_path) and os.path.getsize(tmp_path) > 0:
            with open(tmp_path, 'rb') as f:
                audio_data = f.read()
            
            # 7. Base64编码并输出到stdout
            wav_b64 = base64.b64encode(audio_data).decode('utf-8')
            print(wav_b64)
        
    except Exception as e:
        # 将错误信息输出到stderr
        print(f"TTS Synthesizer Error: {e}", file=sys.stderr)
        
    finally:
        # 8. 清理资源
        if engine:
            del engine
        if tmp_path and os.path.exists(tmp_path):
            try:
                os.unlink(tmp_path)
            except:
                pass

if __name__ == "__main__":
    # 从命令行参数获取输入文本
    # sys.argv[0] 是脚本名, sys.argv[1] 是第一个参数
    if len(sys.argv) > 1:
        # 只获取第一个参数作为输入文本
        input_text = sys.argv[1]
        text_to_wav(input_text)
    else:
        print("Usage: python tts_synthesizer.py \"Your text here\"", file=sys.stderr)