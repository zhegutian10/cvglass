import numpy as np
from collections import deque
import math

class IMUProcessor:
    """
    IMU处理器 - 处理陀螺仪和加速度计数据
    
    这个模块被main.py中的handle_imu_data调用
    """
    
    def __init__(self, buffer_size=10):
        """
        初始化IMU处理器
        
        Args:
            buffer_size: 数据缓冲区大小
        """
        # 数据缓冲区
        self.accel_buffer = deque(maxlen=buffer_size)
        self.gyro_buffer = deque(maxlen=buffer_size)
        self.orientation_buffer = deque(maxlen=buffer_size)
        
        # 运动状态
        self.motion_state = "静止"
        self.last_motion_time = 0
        
        # 跌倒检测阈值
        self.fall_threshold = 20.0  # m/s²
        
        #print("[IMU处理器] 初始化完成")
    
    async def process_imu_data(self, imu_data: dict):
        """
        处理IMU数据 - 主入口函数
        
        Args:
            imu_data: IMU数据字典 {ts, accel, gyro, orientation}
        
        Returns:
            dict: 处理结果
        """
        try:
            # 提取数据
            accel = imu_data.get('accel', {})
            gyro = imu_data.get('gyro', {})
            orientation = imu_data.get('orientation', {})
            
            # 添加到缓冲区
            self.accel_buffer.append(accel)
            self.gyro_buffer.append(gyro)
            self.orientation_buffer.append(orientation)
            
            # 分析数据
            result = {
                'orientation': self._analyze_orientation(orientation),
                'motion_state': self._detect_motion(accel),
                'fall_detected': self._detect_fall(accel),
                'heading': self._calculate_heading(orientation)
            }
            
            return result
            
        except Exception as e:
            print(f"[IMU处理器] 错误: {e}")
            return None
    
    def _analyze_orientation(self, orientation: dict) -> dict:
        """
        分析设备方向
        
        Args:
            orientation: {alpha, beta, gamma}
        
        Returns:
            方向信息
        """
        alpha = orientation.get('alpha', 0)  # 指南针方向 (0-360)
        beta = orientation.get('beta', 0)    # 前后倾斜 (-180 to 180)
        gamma = orientation.get('gamma', 0)  # 左右倾斜 (-90 to 90)
        
        # 判断设备姿态
        if abs(beta) < 30 and abs(gamma) < 30:
            posture = "平放"
        elif beta > 60:
            posture = "竖直向上"
        elif beta < -60:
            posture = "竖直向下"
        else:
            posture = "倾斜"
        
        return {
            'alpha': alpha,
            'beta': beta,
            'gamma': gamma,
            'posture': posture
        }
    
    def _detect_motion(self, accel: dict) -> str:
        """
        检测运动状态
        
        通过分析加速度的变化判断用户是否在移动
        """
        if len(self.accel_buffer) < 3:
            return "未知"
        
        # 计算加速度的标准差
        accel_x = [a.get('x', 0) for a in self.accel_buffer]
        accel_y = [a.get('y', 0) for a in self.accel_buffer]
        accel_z = [a.get('z', 0) for a in self.accel_buffer]
        
        std_x = np.std(accel_x)
        std_y = np.std(accel_y)
        std_z = np.std(accel_z)
        
        total_std = std_x + std_y + std_z
        
        # 根据标准差判断运动状态
        if total_std < 0.5:
            return "静止"
        elif total_std < 2.0:
            return "行走"
        else:
            return "跑步"
    
    def _detect_fall(self, accel: dict) -> bool:
        """
        检测跌倒
        
        通过检测加速度的突变判断是否跌倒
        """
        # 计算加速度的模
        x = accel.get('x', 0)
        y = accel.get('y', 0)
        z = accel.get('z', 0)
        
        magnitude = math.sqrt(x**2 + y**2 + z**2)
        
        # 如果加速度突然增大，可能是跌倒
        if magnitude > self.fall_threshold:
            print("[IMU处理器] 检测到可能的跌倒!")
            return True
        
        return False
    
    def _calculate_heading(self, orientation: dict) -> dict:
        """
        计算朝向
        
        返回用户面向的方向
        """
        alpha = orientation.get('alpha', 0)
        
        # 将角度转换为方向
        if 337.5 <= alpha or alpha < 22.5:
            direction = "北"
        elif 22.5 <= alpha < 67.5:
            direction = "东北"
        elif 67.5 <= alpha < 112.5:
            direction = "东"
        elif 112.5 <= alpha < 157.5:
            direction = "东南"
        elif 157.5 <= alpha < 202.5:
            direction = "南"
        elif 202.5 <= alpha < 247.5:
            direction = "西南"
        elif 247.5 <= alpha < 292.5:
            direction = "西"
        else:
            direction = "西北"
        
        return {
            'angle': alpha,
            'direction': direction
        }