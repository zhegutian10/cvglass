# 模型测试环境说明

本目录包含一个用于测试和比较不同模型性能的轻量级环境。它由一个Web界面 (`index.html`) 和一个FastAPI后端 (`testr.py`) 组成。

## 如何使用

1.  **启动测试服务器:**
    在终端中，导航到 `test` 目录并运行 `testr.py`：
    ```bash
    cd test
    python testr.py
    ```
    这将在 `http://localhost:8002` 上启动一个FastAPI服务器。服务器将首先运行一个模拟测试，然后等待来自Web界面的HTTP请求。

2.  **打开Web界面:**
    在您的网络浏览器中直接打开 `test/index.html` 文件。您将看到一个仪表板，其中包含用于切换不同类型模型的选项（例如，Qwen、计算机视觉、TTS）。

3.  **切换模型:**
    使用下拉菜单选择一个新模型，然后单击“切换模型”按钮。Web界面将向 `testr.py` 服务器发送一个API请求。服务器将在其控制台中打印一条消息，确认模型已成功切换，并且状态将更新在Web界面上。

## 与主应用程序集成

您无需修改现有的主应用程序代码 (`main.py`, `video_processor.py`, 等)。相反，您可以通过以下方式之一将此测试环境与您的应用程序集成：

### 方法1：通过API获取当前模型

在您的主应用程序的处理器文件中 (例如 `video_processor.py`), 您可以向 `testr.py` 发送一个HTTP请求，以获取当前为特定任务选择的模型。

-   **在 `testr.py` 中添加一个端点:**
    ```python
    @app.get("/get_current_models")
    async def get_current_models():
        return current_models
    ```

-   **在您的处理器中调用该端点:**
    ```python
    import requests

    def get_active_cv_model():
        try:
            response = requests.get("http://localhost:8002/get_current_models")
            response.raise_for_status()
            models = response.json()
            return models.get("cv", "opencv") # 默认为 'opencv'
        except requests.RequestException as e:
            print(f"无法连接到测试服务器: {e}")
            return "opencv" # 回退到默认值

    # 在您的处理逻辑中使用它
    active_model = get_active_cv_model()
    if active_model == "pytorch":
        # 调用PyTorch模型
        pass
    else:
        # 调用OpenCV模型
        pass
    ```

### 方法2：使用共享配置文件

或者，`testr.py` 和您的主应用程序可以共享一个配置文件 (例如 `config.json`)。

-   **当模型切换时，`testr.py` 更新配置文件:**
    ```python
    import json

    def update_config(model_type, model_name):
        # 读取、更新并写回config.json
        with open("config.json", "r+") as f:
            config = json.load(f)
            config["models"][model_type] = model_name
            f.seek(0)
            json.dump(config, f, indent=4)
            f.truncate()
    ```

-   **您的主应用程序从配置文件中读取模型:**
    ```python
    import json

    def load_model_from_config():
        with open("config.json", "r") as f:
            config = json.load(f)
            model_name = config["models"]["cv"]
            # 根据model_name加载相应的模型
    ```

这些方法使您能够将模型切换逻辑与主应用程序分离，从而实现更轻松、更安全的测试。