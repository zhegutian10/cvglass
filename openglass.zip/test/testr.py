import uvicorn
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import os

# 1. 初始化 FastAPI 应用
app = FastAPI()

# 2. 全局状态，用于跟踪当前激活的模型
# 在实际应用中，这里可能会是加载后的模型对象
current_models = {
    "qwen": "qwen",
    "cv": "opencv",
    "tts": "default_tts"
}

# Pydantic 模型，用于验证请求体
class ModelSwitchRequest(BaseModel):
    model_type: str
    model_name: str

# 3. API 端点，用于切换模型
@app.post("/switch_model")
async def switch_model(request: ModelSwitchRequest):
    """
    接收前端请求，切换指定类型的模型。
    """
    model_type = request.model_type
    model_name = request.model_name

    if model_type not in current_models:
        raise HTTPException(status_code=404, detail=f"Model type '{model_type}' not found.")

    print(f"收到切换请求: 类型='{model_type}', 模型='{model_name}'")
    current_models[model_type] = model_name
    
    response_message = f"Successfully switched {model_type} model to {model_name}."
    print(response_message)
    
    return {"message": response_message}

# 4. 封装的测试功能（占位符）
# 这些函数模拟了主应用中的核心功能，并可以根据 current_models 的状态改变其行为

def recognize_speech(audio_data):
    """
    模拟语音识别功能。
    """
    model = current_models.get("qwen", "default")
    print(f"--- 使用模型 '{model}' 进行语音识别 ---")
    # 在这里添加调用不同语音识别模型的逻辑
    if model == "doubao":
        return f"豆包模型识别结果: [模拟]"
    elif model == "deepsek":
        return f"Deepseek模型识别结果: [模拟]"
    else: # qwen
        return f"Qwen模型识别结果: [模拟]"

def process_image(image_data):
    """
    模拟图像处理功能。
    """
    model = current_models.get("cv", "default")
    print(f"--- 使用模型 '{model}' 进行图像处理 ---")
    # 在这里添加调用不同CV模型的逻辑
    if model == "pytorch":
        return f"PyTorch模型处理结果: [模拟]"
    else: # opencv
        return f"OpenCV模型处理结果: [模拟]"

def synthesize_speech(text):
    """
    模拟文本转语音功能。
    """
    model = current_models.get("tts", "default")
    print(f"--- 使用模型 '{model}' 进行语音合成 ---")
    # 在这里添加调用不同TTS模型的逻辑
    if model == "new_tts_1":
        return f"新TTS模型1合成的音频: [模拟数据]"
    elif model == "new_tts_2":
        return f"新TTS模型2合成的音频: [模拟数据]"
    else: # default_tts
        return f"默认TTS模型合成的音频: [模拟数据]"

# 示例：如何调用这些测试函数
def run_tests():
    print("\n--- 开始模拟测试 ---")
    
    # 模拟语音识别
    recognize_speech("...some audio data...")
    
    # 模拟图像处理
    process_image("...some image data...")
    
    # 模拟语音合成
    synthesize_speech("你好，这是一个测试。")
    
    print("--- 模拟测试结束 ---\n")


# 5. 主程序入口
if __name__ == "__main__":
    # 运行模拟测试
    run_tests()
    
    # 启动服务器
    port = int(os.getenv("TESTR_PORT", 8002))
    print(f"启动测试服务器，访问地址: http://localhost:{port}")
    uvicorn.run(app, host="0.0.0.0", port=port)
