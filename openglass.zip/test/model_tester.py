"""
模型测试接口
用于测试第三方视觉模型、大语言模型、语音模型

使用方法：
1. 导入此模块
2. 创建 ModelTester 实例
3. 调用相应的测试方法

示例：
    from modules.model_tester import ModelTester
    
    tester = ModelTester()
    
    # 测试视觉模型
    result = await tester.test_vision_model(image_path="test.jpg")
    
    # 测试大语言模型
    result = await tester.test_llm(prompt="你好")
    
    # 测试语音模型
    result = await tester.test_speech_model(audio_path="test.wav")
"""

import asyncio
import base64
import json
import os
from pathlib import Path
from typing import Optional, Dict, Any, List
import cv2
import numpy as np


class ModelTester:
    """
    模型测试器
    提供统一的接口测试各类AI模型
    """
    
    def __init__(self, config_path: Optional[str] = None):
        """
        初始化模型测试器
        
        Args:
            config_path: 配置文件路径（可选）
        """
        self.config = self._load_config(config_path)
        self.test_results = []
        print("[模型测试器] 初始化完成")
    
    def _load_config(self, config_path: Optional[str]) -> Dict:
        """加载配置文件"""
        default_config = {
            "vision_models": {
                "yolo": {"enabled": True, "model_path": "./models/yolo11m.pt"},
                "qwen_vl": {"enabled": True, "api_key": os.getenv("DASHSCOPE_API_KEY")},
                "custom": {"enabled": False, "endpoint": ""}
            },
            "llm_models": {
                "qwen": {"enabled": True, "api_key": os.getenv("DASHSCOPE_API_KEY")},
                "openai": {"enabled": False, "api_key": ""},
                "custom": {"enabled": False, "endpoint": ""}
            },
            "speech_models": {
                "dashscope_asr": {"enabled": True, "api_key": os.getenv("DASHSCOPE_API_KEY")},
                "dashscope_tts": {"enabled": True, "api_key": os.getenv("DASHSCOPE_API_KEY")},
                "custom": {"enabled": False, "endpoint": ""}
            }
        }
        
        if config_path and Path(config_path).exists():
            try:
                with open(config_path, 'r', encoding='utf-8') as f:
                    user_config = json.load(f)
                    default_config.update(user_config)
            except Exception as e:
                print(f"[模型测试器] 加载配置文件失败: {e}")
        
        return default_config
    
    # ==================== 视觉模型测试 ====================
    
    async def test_vision_model(
        self, 
        image_path: Optional[str] = None,
        image_data: Optional[np.ndarray] = None,
        model_name: str = "qwen_vl",
        prompt: str = "描述这张图片"
    ) -> Dict[str, Any]:
        """
        测试视觉模型
        
        Args:
            image_path: 图片路径
            image_data: 图片数据（numpy数组）
            model_name: 模型名称 (yolo/qwen_vl/custom)
            prompt: 提示词（用于VLM模型）
        
        Returns:
            测试结果字典
        """
        print(f"\n[视觉模型测试] 开始测试 {model_name}")
        
        # 加载图片
        if image_data is None and image_path:
            image_data = cv2.imread(image_path)
            if image_data is None:
                return {"error": f"无法加载图片: {image_path}"}
        
        if image_data is None:
            return {"error": "未提供图片数据"}
        
        result = {
            "model": model_name,
            "type": "vision",
            "success": False,
            "data": None,
            "error": None
        }
        
        try:
            if model_name == "yolo":
                result["data"] = await self._test_yolo(image_data)
                result["success"] = True
                
            elif model_name == "qwen_vl":
                result["data"] = await self._test_qwen_vl(image_data, prompt)
                result["success"] = True
                
            elif model_name == "custom":
                result["data"] = await self._test_custom_vision(image_data, prompt)
                result["success"] = True
                
            else:
                result["error"] = f"未知的视觉模型: {model_name}"
        
        except Exception as e:
            result["error"] = str(e)
            print(f"[视觉模型测试] 错误: {e}")
            import traceback
            traceback.print_exc()
        
        self.test_results.append(result)
        return result
    
    async def _test_yolo(self, image: np.ndarray) -> Dict:
        """测试YOLO模型"""
        try:
            from ultralytics import YOLO
            
            model_path = self.config["vision_models"]["yolo"]["model_path"]
            model = YOLO(model_path)
            
            results = model(image, verbose=False)
            
            detections = []
            for r in results:
                boxes = r.boxes
                for box in boxes:
                    detections.append({
                        "class": r.names[int(box.cls[0])],
                        "confidence": float(box.conf[0]),
                        "bbox": box.xyxy[0].tolist()
                    })
            
            return {
                "detections": detections,
                "count": len(detections)
            }
        
        except Exception as e:
            raise Exception(f"YOLO测试失败: {e}")
    
    async def _test_qwen_vl(self, image: np.ndarray, prompt: str) -> Dict:
        """测试Qwen-VL模型"""
        try:
            import dashscope
            from dashscope import MultiModalConversation
            
            api_key = self.config["vision_models"]["qwen_vl"]["api_key"]
            if not api_key:
                raise Exception("未配置Qwen-VL API密钥")
            
            dashscope.api_key = api_key
            
            # 编码图片
            _, buffer = cv2.imencode('.jpg', image)
            image_base64 = base64.b64encode(buffer).decode('utf-8')
            
            messages = [{
                'role': 'user',
                'content': [
                    {'image': f'data:image/jpeg;base64,{image_base64}'},
                    {'text': prompt}
                ]
            }]
            
            response = MultiModalConversation.call(
                model='qwen-vl-max',
                messages=messages
            )
            
            if response.status_code == 200:
                return {
                    "response": response.output.choices[0].message.content[0]['text'],
                    "usage": response.usage
                }
            else:
                raise Exception(f"API调用失败: {response.message}")
        
        except Exception as e:
            raise Exception(f"Qwen-VL测试失败: {e}")
    
    async def _test_custom_vision(self, image: np.ndarray, prompt: str) -> Dict:
        """测试自定义视觉模型"""
        # 这里可以添加自定义视觉模型的测试代码
        return {
            "message": "自定义视觉模型接口，请实现具体逻辑",
            "endpoint": self.config["vision_models"]["custom"]["endpoint"]
        }
    
    # ==================== 大语言模型测试 ====================
    
    async def test_llm(
        self,
        prompt: str,
        model_name: str = "qwen",
        system_prompt: Optional[str] = None,
        history: Optional[List[Dict]] = None
    ) -> Dict[str, Any]:
        """
        测试大语言模型
        
        Args:
            prompt: 用户输入
            model_name: 模型名称 (qwen/openai/custom)
            system_prompt: 系统提示词
            history: 对话历史
        
        Returns:
            测试结果字典
        """
        print(f"\n[大语言模型测试] 开始测试 {model_name}")
        
        result = {
            "model": model_name,
            "type": "llm",
            "success": False,
            "data": None,
            "error": None
        }
        
        try:
            if model_name == "qwen":
                result["data"] = await self._test_qwen_llm(prompt, system_prompt, history)
                result["success"] = True
                
            elif model_name == "openai":
                result["data"] = await self._test_openai_llm(prompt, system_prompt, history)
                result["success"] = True
                
            elif model_name == "custom":
                result["data"] = await self._test_custom_llm(prompt, system_prompt, history)
                result["success"] = True
                
            else:
                result["error"] = f"未知的LLM模型: {model_name}"
        
        except Exception as e:
            result["error"] = str(e)
            print(f"[大语言模型测试] 错误: {e}")
            import traceback
            traceback.print_exc()
        
        self.test_results.append(result)
        return result
    
    async def _test_qwen_llm(
        self,
        prompt: str,
        system_prompt: Optional[str],
        history: Optional[List[Dict]]
    ) -> Dict:
        """测试Qwen大语言模型"""
        try:
            import dashscope
            from dashscope import Generation
            
            api_key = self.config["llm_models"]["qwen"]["api_key"]
            if not api_key:
                raise Exception("未配置Qwen API密钥")
            
            dashscope.api_key = api_key
            
            messages = []
            if system_prompt:
                messages.append({'role': 'system', 'content': system_prompt})
            
            if history:
                messages.extend(history)
            
            messages.append({'role': 'user', 'content': prompt})
            
            response = Generation.call(
                model='qwen-turbo',
                messages=messages,
                result_format='message'
            )
            
            if response.status_code == 200:
                return {
                    "response": response.output.choices[0].message.content,
                    "usage": response.usage
                }
            else:
                raise Exception(f"API调用失败: {response.message}")
        
        except Exception as e:
            raise Exception(f"Qwen LLM测试失败: {e}")
    
    async def _test_openai_llm(
        self,
        prompt: str,
        system_prompt: Optional[str],
        history: Optional[List[Dict]]
    ) -> Dict:
        """测试OpenAI大语言模型"""
        # 这里可以添加OpenAI模型的测试代码
        return {
            "message": "OpenAI模型接口，请配置API密钥并实现具体逻辑",
            "api_key_configured": bool(self.config["llm_models"]["openai"]["api_key"])
        }
    
    async def _test_custom_llm(
        self,
        prompt: str,
        system_prompt: Optional[str],
        history: Optional[List[Dict]]
    ) -> Dict:
        """测试自定义大语言模型"""
        return {
            "message": "自定义LLM接口，请实现具体逻辑",
            "endpoint": self.config["llm_models"]["custom"]["endpoint"]
        }
    
    # ==================== 语音模型测试 ====================
    
    async def test_speech_model(
        self,
        audio_path: Optional[str] = None,
        audio_data: Optional[bytes] = None,
        model_name: str = "dashscope_asr",
        task: str = "asr"  # asr: 语音识别, tts: 语音合成
    ) -> Dict[str, Any]:
        """
        测试语音模型
        
        Args:
            audio_path: 音频文件路径
            audio_data: 音频数据（字节）
            model_name: 模型名称 (dashscope_asr/dashscope_tts/custom)
            task: 任务类型 (asr/tts)
        
        Returns:
            测试结果字典
        """
        print(f"\n[语音模型测试] 开始测试 {model_name} - 任务: {task}")
        
        result = {
            "model": model_name,
            "type": "speech",
            "task": task,
            "success": False,
            "data": None,
            "error": None
        }
        
        try:
            if task == "asr":
                if model_name == "dashscope_asr":
                    result["data"] = await self._test_dashscope_asr(audio_path, audio_data)
                    result["success"] = True
                elif model_name == "custom":
                    result["data"] = await self._test_custom_asr(audio_path, audio_data)
                    result["success"] = True
                else:
                    result["error"] = f"未知的ASR模型: {model_name}"
            
            elif task == "tts":
                if model_name == "dashscope_tts":
                    result["data"] = await self._test_dashscope_tts("这是一段测试语音")
                    result["success"] = True
                elif model_name == "custom":
                    result["data"] = await self._test_custom_tts("这是一段测试语音")
                    result["success"] = True
                else:
                    result["error"] = f"未知的TTS模型: {model_name}"
            
            else:
                result["error"] = f"未知的任务类型: {task}"
        
        except Exception as e:
            result["error"] = str(e)
            print(f"[语音模型测试] 错误: {e}")
            import traceback
            traceback.print_exc()
        
        self.test_results.append(result)
        return result
    
    async def _test_dashscope_asr(
        self,
        audio_path: Optional[str],
        audio_data: Optional[bytes]
    ) -> Dict:
        """测试DashScope ASR"""
        try:
            import dashscope
            from dashscope.audio.asr import Recognition
            
            api_key = self.config["speech_models"]["dashscope_asr"]["api_key"]
            if not api_key:
                raise Exception("未配置DashScope ASR API密钥")
            
            dashscope.api_key = api_key
            
            if audio_path:
                recognition = Recognition(
                    model='paraformer-realtime-v2',
                    format='wav',
                    sample_rate=16000,
                    callback=None
                )
                
                result = recognition.call(audio_path)
                return {
                    "text": result.get_sentence()['text'] if result else "",
                    "status": "success"
                }
            else:
                return {"message": "需要提供音频文件路径"}
        
        except Exception as e:
            raise Exception(f"DashScope ASR测试失败: {e}")
    
    async def _test_dashscope_tts(self, text: str) -> Dict:
        """测试DashScope TTS"""
        try:
            import dashscope
            from dashscope.audio.tts import SpeechSynthesizer
            
            api_key = self.config["speech_models"]["dashscope_tts"]["api_key"]
            if not api_key:
                raise Exception("未配置DashScope TTS API密钥")
            
            dashscope.api_key = api_key
            
            synthesizer = SpeechSynthesizer(
                model='sambert-zhichu-v1',
                voice='zhixiaobai'
            )
            
            audio = synthesizer.call(text)
            
            return {
                "audio_length": len(audio) if audio else 0,
                "status": "success",
                "message": "TTS合成成功"
            }
        
        except Exception as e:
            raise Exception(f"DashScope TTS测试失败: {e}")
    
    async def _test_custom_asr(
        self,
        audio_path: Optional[str],
        audio_data: Optional[bytes]
    ) -> Dict:
        """测试自定义ASR"""
        return {
            "message": "自定义ASR接口，请实现具体逻辑",
            "endpoint": self.config["speech_models"]["custom"]["endpoint"]
        }
    
    async def _test_custom_tts(self, text: str) -> Dict:
        """测试自定义TTS"""
        return {
            "message": "自定义TTS接口，请实现具体逻辑",
            "endpoint": self.config["speech_models"]["custom"]["endpoint"]
        }
    
    # ==================== 批量测试 ====================
    
    async def run_all_tests(self) -> List[Dict[str, Any]]:
        """
        运行所有启用的模型测试
        
        Returns:
            所有测试结果列表
        """
        print("\n" + "="*50)
        print("开始批量测试所有模型")
        print("="*50)
        
        all_results = []
        
        # 测试视觉模型
        for model_name, config in self.config["vision_models"].items():
            if config.get("enabled"):
                try:
                    # 创建测试图片
                    test_image = np.zeros((480, 640, 3), dtype=np.uint8)
                    cv2.putText(test_image, "Test Image", (200, 240), 
                               cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
                    
                    result = await self.test_vision_model(
                        image_data=test_image,
                        model_name=model_name
                    )
                    all_results.append(result)
                except Exception as e:
                    print(f"测试 {model_name} 失败: {e}")
        
        # 测试大语言模型
        for model_name, config in self.config["llm_models"].items():
            if config.get("enabled"):
                try:
                    result = await self.test_llm(
                        prompt="你好，请介绍一下你自己",
                        model_name=model_name
                    )
                    all_results.append(result)
                except Exception as e:
                    print(f"测试 {model_name} 失败: {e}")
        
        # 测试语音模型
        for model_name, config in self.config["speech_models"].items():
            if config.get("enabled") and "tts" in model_name:
                try:
                    result = await self.test_speech_model(
                        model_name=model_name,
                        task="tts"
                    )
                    all_results.append(result)
                except Exception as e:
                    print(f"测试 {model_name} 失败: {e}")
        
        print("\n" + "="*50)
        print(f"批量测试完成，共 {len(all_results)} 个测试")
        print("="*50)
        
        return all_results
    
    def get_test_summary(self) -> Dict[str, Any]:
        """
        获取测试摘要
        
        Returns:
            测试摘要字典
        """
        total = len(self.test_results)
        success = sum(1 for r in self.test_results if r["success"])
        failed = total - success
        
        return {
            "total_tests": total,
            "successful": success,
            "failed": failed,
            "success_rate": f"{(success/total*100):.1f}%" if total > 0 else "0%",
            "results": self.test_results
        }
    
    def save_results(self, output_path: str = "test_results.json"):
        """
        保存测试结果到文件
        
        Args:
            output_path: 输出文件路径
        """
        summary = self.get_test_summary()
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)
        
        print(f"\n[模型测试器] 测试结果已保存到: {output_path}")


# ==================== 使用示例 ====================

async def example_usage():
    """使用示例"""
    print("="*60)
    print("模型测试器 - 使用示例")
    print("="*60)
    
    # 创建测试器
    tester = ModelTester()
    
    # 示例1: 测试视觉模型
    print("\n【示例1】测试Qwen-VL视觉模型")
    test_image = np.zeros((480, 640, 3), dtype=np.uint8)
    cv2.putText(test_image, "Hello World", (200, 240), 
               cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
    
    vision_result = await tester.test_vision_model(
        image_data=test_image,
        model_name="qwen_vl",
        prompt="描述这张图片中的文字"
    )
    print(f"视觉模型测试结果: {vision_result}")
    
    # 示例2: 测试大语言模型
    print("\n【示例2】测试Qwen大语言模型")
    llm_result = await tester.test_llm(
        prompt="请用一句话介绍人工智能",
        model_name="qwen"
    )
    print(f"LLM测试结果: {llm_result}")
    
    # 示例3: 测试语音合成
    print("\n【示例3】测试语音合成模型")
    tts_result = await tester.test_speech_model(
        model_name="dashscope_tts",
        task="tts"
    )
    print(f"TTS测试结果: {tts_result}")
    
    # 示例4: 批量测试所有模型
    print("\n【示例4】批量测试所有启用的模型")
    all_results = await tester.run_all_tests()
    
    # 获取测试摘要
    summary = tester.get_test_summary()
    print(f"\n测试摘要:")
    print(f"  总测试数: {summary['total_tests']}")
    print(f"  成功: {summary['successful']}")
    print(f"  失败: {summary['failed']}")
    print(f"  成功率: {summary['success_rate']}")
    
    # 保存结果
    tester.save_results("model_test_results.json")


if __name__ == "__main__":
    # 运行示例
    asyncio.run(example_usage())