"""
系统监控程序
用于监测视频、音频、文字状态信息
"""

import asyncio
import json
import time
from datetime import datetime
from collections import deque
from typing import Dict, List
import os
from pathlib import Path

class SystemMonitor:
    def __init__(self, log_dir="./monitor/logs"):
        """
        初始化系统监控器
        
        Args:
            log_dir: 日志保存目录
        """
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        
        # 监控数据缓存（最近100条）
        self.video_stats = deque(maxlen=100)
        self.audio_stats = deque(maxlen=100)
        self.text_stats = deque(maxlen=100)
        
        # 实时统计
        self.stats = {
            'video': {
                'total_frames': 0,
                'fps': 0,
                'avg_processing_time': 0,
                'last_frame_time': None,
                'resolution': None,
                'errors': 0
            },
            'audio': {
                'total_chunks': 0,
                'sample_rate': 0,
                'avg_processing_time': 0,
                'last_chunk_time': None,
                'errors': 0
            },
            'text': {
                'total_messages': 0,
                'avg_length': 0,
                'last_message_time': None,
                'errors': 0
            },
            'system': {
                'start_time': datetime.now().isoformat(),
                'uptime': 0,
                'total_errors': 0
            }
        }
        
        # 性能阈值
        self.thresholds = {
            'video_fps_min': 5,
            'video_processing_max': 0.5,  # 秒
            'audio_processing_max': 0.3,
            'text_processing_max': 0.2
        }
        
        # 告警列表
        self.alerts = deque(maxlen=50)
        
        print(f"系统监控器已初始化，日志目录: {self.log_dir}")
    
    def log_video_frame(self, frame_data: Dict):
        """
        记录视频帧信息
        
        Args:
            frame_data: {
                'timestamp': 时间戳,
                'resolution': (width, height),
                'processing_time': 处理时间(秒),
                'detections': 检测结果数量,
                'error': 错误信息(可选)
            }
        """
        current_time = time.time()
        
        # 更新统计
        self.stats['video']['total_frames'] += 1
        self.stats['video']['last_frame_time'] = datetime.now().isoformat()
        
        if frame_data.get('resolution'):
            self.stats['video']['resolution'] = frame_data['resolution']
        
        if frame_data.get('error'):
            self.stats['video']['errors'] += 1
            self.stats['system']['total_errors'] += 1
            self._add_alert('video', f"视频处理错误: {frame_data['error']}")
        
        # 计算FPS
        if len(self.video_stats) > 0:
            time_diff = current_time - self.video_stats[-1]['timestamp']
            if time_diff > 0:
                fps = 1.0 / time_diff
                self.stats['video']['fps'] = round(fps, 2)
                
                # 检查FPS是否过低
                if fps < self.thresholds['video_fps_min']:
                    self._add_alert('video', f"FPS过低: {fps:.2f}")
        
        # 计算平均处理时间
        processing_time = frame_data.get('processing_time', 0)
        if processing_time > 0:
            total_time = sum(f.get('processing_time', 0) for f in self.video_stats)
            avg_time = (total_time + processing_time) / (len(self.video_stats) + 1)
            self.stats['video']['avg_processing_time'] = round(avg_time, 3)
            
            # 检查处理时间是否过长
            if processing_time > self.thresholds['video_processing_max']:
                self._add_alert('video', f"处理时间过长: {processing_time:.3f}秒")
        
        # 添加到缓存
        frame_data['timestamp'] = current_time
        self.video_stats.append(frame_data)
    
    def log_audio_chunk(self, audio_data: Dict):
        """
        记录音频块信息
        
        Args:
            audio_data: {
                'timestamp': 时间戳,
                'sample_rate': 采样率,
                'duration': 时长(秒),
                'processing_time': 处理时间(秒),
                'recognized_text': 识别文本(可选),
                'error': 错误信息(可选)
            }
        """
        current_time = time.time()
        
        # 更新统计
        self.stats['audio']['total_chunks'] += 1
        self.stats['audio']['last_chunk_time'] = datetime.now().isoformat()
        
        if audio_data.get('sample_rate'):
            self.stats['audio']['sample_rate'] = audio_data['sample_rate']
        
        if audio_data.get('error'):
            self.stats['audio']['errors'] += 1
            self.stats['system']['total_errors'] += 1
            self._add_alert('audio', f"音频处理错误: {audio_data['error']}")
        
        # 计算平均处理时间
        processing_time = audio_data.get('processing_time', 0)
        if processing_time > 0:
            total_time = sum(a.get('processing_time', 0) for a in self.audio_stats)
            avg_time = (total_time + processing_time) / (len(self.audio_stats) + 1)
            self.stats['audio']['avg_processing_time'] = round(avg_time, 3)
            
            # 检查处理时间
            if processing_time > self.thresholds['audio_processing_max']:
                self._add_alert('audio', f"处理时间过长: {processing_time:.3f}秒")
        
        # 添加到缓存
        audio_data['timestamp'] = current_time
        self.audio_stats.append(audio_data)
    
    def log_text_message(self, text_data: Dict):
        """
        记录文本消息信息
        
        Args:
            text_data: {
                'timestamp': 时间戳,
                'type': 消息类型 ('user'/'assistant'/'system'),
                'content': 消息内容,
                'processing_time': 处理时间(秒),
                'error': 错误信息(可选)
            }
        """
        current_time = time.time()
        
        # 更新统计
        self.stats['text']['total_messages'] += 1
        self.stats['text']['last_message_time'] = datetime.now().isoformat()
        
        if text_data.get('error'):
            self.stats['text']['errors'] += 1
            self.stats['system']['total_errors'] += 1
            self._add_alert('text', f"文本处理错误: {text_data['error']}")
        
        # 计算平均长度
        content = text_data.get('content', '')
        if content:
            total_length = sum(len(t.get('content', '')) for t in self.text_stats)
            avg_length = (total_length + len(content)) / (len(self.text_stats) + 1)
            self.stats['text']['avg_length'] = round(avg_length, 1)
        
        # 检查处理时间
        processing_time = text_data.get('processing_time', 0)
        if processing_time > self.thresholds['text_processing_max']:
            self._add_alert('text', f"处理时间过长: {processing_time:.3f}秒")
        
        # 添加到缓存
        text_data['timestamp'] = current_time
        self.text_stats.append(text_data)
    
    def _add_alert(self, category: str, message: str):
        """添加告警"""
        alert = {
            'timestamp': datetime.now().isoformat(),
            'category': category,
            'message': message
        }
        self.alerts.append(alert)
        print(f"⚠️ 告警 [{category}]: {message}")
    
    def get_stats(self) -> Dict:
        """获取当前统计信息"""
        # 更新运行时间
        start_time = datetime.fromisoformat(self.stats['system']['start_time'])
        uptime = (datetime.now() - start_time).total_seconds()
        self.stats['system']['uptime'] = round(uptime, 1)
        
        return self.stats
    
    def get_alerts(self, limit: int = 10) -> List[Dict]:
        """获取最近的告警"""
        return list(self.alerts)[-limit:]
    
    def get_recent_data(self, data_type: str, limit: int = 10) -> List[Dict]:
        """
        获取最近的数据
        
        Args:
            data_type: 'video', 'audio', 'text'
            limit: 返回数量
        """
        if data_type == 'video':
            return list(self.video_stats)[-limit:]
        elif data_type == 'audio':
            return list(self.audio_stats)[-limit:]
        elif data_type == 'text':
            return list(self.text_stats)[-limit:]
        return []
    
    def save_log(self):
        """保存日志到文件"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_file = self.log_dir / f"monitor_log_{timestamp}.json"
        
        log_data = {
            'stats': self.stats,
            'alerts': list(self.alerts),
            'recent_video': list(self.video_stats)[-10:],
            'recent_audio': list(self.audio_stats)[-10:],
            'recent_text': list(self.text_stats)[-10:]
        }
        
        with open(log_file, 'w', encoding='utf-8') as f:
            json.dump(log_data, f, ensure_ascii=False, indent=2)
        
        print(f"日志已保存: {log_file}")
        return log_file
    
    def print_summary(self):
        """打印监控摘要"""
        stats = self.get_stats()
        
        print("\n" + "="*60)
        print("系统监控摘要".center(60))
        print("="*60)
        
        print(f"\n📹 视频统计:")
        print(f"  总帧数: {stats['video']['total_frames']}")
        print(f"  当前FPS: {stats['video']['fps']}")
        print(f"  平均处理时间: {stats['video']['avg_processing_time']}秒")
        print(f"  分辨率: {stats['video']['resolution']}")
        print(f"  错误数: {stats['video']['errors']}")
        
        print(f"\n🎤 音频统计:")
        print(f"  总块数: {stats['audio']['total_chunks']}")
        print(f"  采样率: {stats['audio']['sample_rate']} Hz")
        print(f"  平均处理时间: {stats['audio']['avg_processing_time']}秒")
        print(f"  错误数: {stats['audio']['errors']}")
        
        print(f"\n💬 文本统计:")
        print(f"  总消息数: {stats['text']['total_messages']}")
        print(f"  平均长度: {stats['text']['avg_length']} 字符")
        print(f"  错误数: {stats['text']['errors']}")
        
        print(f"\n⚙️ 系统统计:")
        print(f"  运行时间: {stats['system']['uptime']}秒")
        print(f"  总错误数: {stats['system']['total_errors']}")
        
        if self.alerts:
            print(f"\n⚠️ 最近告警 (共{len(self.alerts)}条):")
            for alert in list(self.alerts)[-5:]:
                print(f"  [{alert['category']}] {alert['message']}")
        
        print("="*60 + "\n")


# 全局监控器实例
monitor = SystemMonitor()


# 使用示例
if __name__ == "__main__":
    # 模拟视频帧
    monitor.log_video_frame({
        'resolution': (1280, 720),
        'processing_time': 0.05,
        'detections': 3
    })
    
    # 模拟音频块
    monitor.log_audio_chunk({
        'sample_rate': 16000,
        'duration': 0.5,
        'processing_time': 0.1,
        'recognized_text': "你好"
    })
    
    # 模拟文本消息
    monitor.log_text_message({
        'type': 'user',
        'content': "前面有什么？",
        'processing_time': 0.05
    })
    
    # 打印摘要
    monitor.print_summary()
    
    # 保存日志
    monitor.save_log()