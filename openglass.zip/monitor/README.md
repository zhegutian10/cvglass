# 系统监控模块

## 📊 功能概述

本监控模块用于实时监测盲人导航系统的运行状态，包括视频处理、音频处理、文本交互等各个方面的性能指标和错误信息。

## 📁 文件结构

```
monitor/
├── system_monitor.py       # 核心监控类
├── monitor_dashboard.html  # Web监控面板
├── README.md              # 本文件
└── logs/                  # 日志存储目录（自动创建）
    └── monitor_log_*.json # 监控日志文件
```

## 🚀 快速开始

### 1. 在主程序中集成监控

```python
from monitor.system_monitor import monitor

# 记录视频帧处理
monitor.log_video_frame({
    'resolution': (1280, 720),
    'processing_time': 0.05,
    'detections': 3
})

# 记录音频处理
monitor.log_audio_chunk({
    'sample_rate': 16000,
    'duration': 0.5,
    'processing_time': 0.1,
    'recognized_text': "你好"
})

# 记录文本消息
monitor.log_text_message({
    'type': 'user',
    'content': "前面有什么？",
    'processing_time': 0.05
})
```

### 2. 启动监控面板

#### 方法A: 直接打开HTML文件
双击 `monitor_dashboard.html` 文件

#### 方法B: 使用HTTP服务器
```bash
cd monitor
python -m http.server 8082
```
然后访问: http://localhost:8082/monitor_dashboard.html

#### 方法C: 集成到主服务器
在 `main.py` 中添加：
```python
from fastapi.staticfiles import StaticFiles
app.mount("/monitor", StaticFiles(directory="monitor"), name="monitor")
```
访问: http://localhost:8081/monitor/monitor_dashboard.html

### 3. 连接监控面板

1. 打开监控面板
2. 点击"连接服务器"
3. 输入服务器地址（如：`localhost:8081`）
4. 查看实时监控数据

## 📈 监控指标

### 视频监控
- **总帧数**: 已处理的视频帧总数
- **当前FPS**: 实时帧率
- **平均处理时间**: 单帧平均处理耗时
- **分辨率**: 视频分辨率
- **错误数**: 处理失败次数

### 音频监控
- **总块数**: 已处理的音频块总数
- **采样率**: 音频采样率
- **平均处理时间**: 单块平均处理耗时
- **错误数**: 处理失败次数

### 文本监控
- **总消息数**: 处理的消息总数
- **平均长度**: 消息平均字符数
- **错误数**: 处理失败次数

### 系统监控
- **运行时间**: 系统运行时长
- **总错误数**: 所有模块的错误总数
- **启动时间**: 系统启动时间

## ⚠️ 告警系统

监控系统会自动检测以下异常情况并发出告警：

| 告警类型 | 触发条件 | 建议处理 |
|---------|---------|---------|
| FPS过低 | FPS < 5 | 检查GPU负载，优化模型 |
| 处理时间过长 | 视频>0.5s, 音频>0.3s | 检查网络延迟，优化算法 |
| 错误率过高 | 错误数>阈值 | 查看日志，修复bug |

## 📝 日志管理

### 手动保存日志
```python
from monitor.system_monitor import monitor

# 保存当前监控数据
log_file = monitor.save_log()
print(f"日志已保存: {log_file}")
```

### 自动保存日志
```python
import asyncio

async def auto_save_logs():
    while True:
        await asyncio.sleep(3600)  # 每小时
        monitor.save_log()

# 在主程序启动时运行
asyncio.create_task(auto_save_logs())
```

### 日志格式
日志以JSON格式保存，包含：
```json
{
  "stats": {
    "video": {...},
    "audio": {...},
    "text": {...},
    "system": {...}
  },
  "alerts": [...],
  "recent_video": [...],
  "recent_audio": [...],
  "recent_text": [...]
}
```

## 🔧 自定义配置

### 修改告警阈值
```python
from monitor.system_monitor import monitor

monitor.thresholds = {
    'video_fps_min': 8,              # 最低FPS
    'video_processing_max': 0.3,     # 最大处理时间（秒）
    'audio_processing_max': 0.2,
    'text_processing_max': 3.0
}
```

### 修改缓存大小
```python
# 在system_monitor.py中修改
self.video_stats = deque(maxlen=200)  # 默认100
self.audio_stats = deque(maxlen=200)
self.text_stats = deque(maxlen=200)
```

## 📊 数据导出

### 导出为CSV
```python
import pandas as pd
from monitor.system_monitor import monitor

# 导出视频数据
video_df = pd.DataFrame(list(monitor.video_stats))
video_df.to_csv('video_stats.csv', index=False)

# 导出音频数据
audio_df = pd.DataFrame(list(monitor.audio_stats))
audio_df.to_csv('audio_stats.csv', index=False)
```

### 导出为Excel
```python
with pd.ExcelWriter('monitor_report.xlsx') as writer:
    video_df.to_excel(writer, sheet_name='Video', index=False)
    audio_df.to_excel(writer, sheet_name='Audio', index=False)
    text_df.to_excel(writer, sheet_name='Text', index=False)
```

## 🐛 调试模式

### 打印实时摘要
```python
from monitor.system_monitor import monitor

# 打印当前统计摘要
monitor.print_summary()
```

### 获取详细数据
```python
# 获取统计数据
stats = monitor.get_stats()
print(stats)

# 获取最近的告警
alerts = monitor.get_alerts(limit=10)
print(alerts)

# 获取最近的处理数据
recent_video = monitor.get_recent_data('video', limit=10)
recent_audio = monitor.get_recent_data('audio', limit=10)
recent_text = monitor.get_recent_data('text', limit=10)
```

## 🔗 API参考

### SystemMonitor类

#### 方法

- `log_video_frame(frame_data: Dict)` - 记录视频帧信息
- `log_audio_chunk(audio_data: Dict)` - 记录音频块信息
- `log_text_message(text_data: Dict)` - 记录文本消息信息
- `get_stats() -> Dict` - 获取当前统计信息
- `get_alerts(limit: int) -> List[Dict]` - 获取最近的告警
- `get_recent_data(data_type: str, limit: int) -> List[Dict]` - 获取最近的数据
- `save_log() -> Path` - 保存日志到文件
- `print_summary()` - 打印监控摘要

#### 属性

- `video_stats` - 视频处理数据缓存
- `audio_stats` - 音频处理数据缓存
- `text_stats` - 文本消息数据缓存
- `stats` - 实时统计数据
- `alerts` - 告警列表
- `thresholds` - 告警阈值配置

## 💡 最佳实践

1. **及时记录**: 在每次处理后立即记录数据
2. **异常捕获**: 使用try-except捕获异常并记录错误
3. **定期保存**: 设置自动保存日志任务
4. **监控告警**: 及时查看和处理告警信息
5. **性能优化**: 根据监控数据优化系统性能
6. **日志清理**: 定期清理旧日志文件

## 📞 技术支持

如有问题，请查看：
- 主项目文档: `readme/开发指南.md`
- 系统日志: `monitor/logs/`
- 告警信息: 监控面板

---

**版本**: 1.0.0  
**最后更新**: 2025-11-04