# ASR与Qwen语音交互技术原理

## 概述

本文档详细说明AI眼镜系统中语音识别（ASR）和大模型对话（Qwen）的完整技术流程，包括音频上传、识别、处理、语音合成和返回的全过程。

---

## 一、系统架构图

```
┌─────────────┐
│  ESP32设备  │
│  (麦克风)   │
└──────┬──────┘
       │ WebSocket (/ws_audio)
       │ PCM 16kHz 音频流
       ▼
┌─────────────────────────────────────────────────────────┐
│                    服务器 (app_main.py)                  │
│  ┌──────────────────────────────────────────────────┐  │
│  │  1. 音频接收与ASR识别                             │  │
│  │     - 接收PCM音频流                               │  │
│  │     - 调用阿里云DashScope ASR                     │  │
│  │     - 实时转文字                                  │  │
│  └────────────────┬─────────────────────────────────┘  │
│                   │ 识别文本                            │
│                   ▼                                     │
│  ┌──────────────────────────────────────────────────┐  │
│  │  2. 命令路由与处理 (start_ai_with_text_custom)   │  │
│  │     - 关键字匹配（导航命令）                      │  │
│  │     - 或进入Qwen对话                              │  │
│  └────────────────┬─────────────────────────────────┘  │
│                   │                                     │
│         ┌─────────┴─────────┐                          │
│         │                   │                          │
│    [导航命令]          [对话请求]                       │
│         │                   │                          │
│         ▼                   ▼                          │
│  ┌─────────────┐   ┌──────────────────────────────┐  │
│  │ 播放预录音  │   │  3. Qwen多模态对话            │  │
│  │ (audio_     │   │     - 抓取当前视频帧          │  │
│  │  player.py) │   │     - 组装图像+文本           │  │
│  │             │   │     - 调用Qwen-Omni-Turbo     │  │
│  └─────────────┘   │     - 流式返回文本+音频       │  │
│                    └────────────┬─────────────────┘  │
│                                 │ 24kHz PCM音频      │
│                                 ▼                     │
│  ┌──────────────────────────────────────────────────┐  │
│  │  4. 音频处理与分发 (audio_stream.py)             │  │
│  │     - 降采样 24kHz → 8kHz                         │  │
│  │     - 音量调节                                    │  │
│  │     - 实时分发到所有连接                          │  │
│  └────────────────┬─────────────────────────────────┘  │
└───────────────────┼──────────────────────────────────┘
                    │ HTTP Stream (/stream.wav)
                    │ 8kHz PCM WAV格式
                    ▼
            ┌───────────────┐
            │  ESP32设备     │
            │  (扬声器)      │
            └───────────────┘
```

---

## 二、详细技术流程

### 2.1 音频上传与ASR识别

#### 2.1.1 WebSocket连接建立

**接口**: `/ws_audio`  
**协议**: WebSocket  
**文件**: [`app_main.py`](../app_main.py:963)

```python
@app.websocket("/ws_audio")
async def ws_audio(ws: WebSocket):
    await ws.accept()
    # 建立连接后等待START命令
```

#### 2.1.2 音频格式规范

**上行音频格式**（ESP32 → 服务器）:
- **采样率**: 16000 Hz
- **声道数**: 1（单声道）
- **位深度**: 16-bit
- **编码**: PCM（未压缩）
- **传输**: 二进制WebSocket消息
- **分片**: 每20ms一个数据包（640字节）

```python
# 音频参数定义 (app_main.py:194-198)
SAMPLE_RATE  = 16000
AUDIO_FMT    = "pcm"
CHUNK_MS     = 20
BYTES_CHUNK  = SAMPLE_RATE * CHUNK_MS // 1000 * 2  # 640字节
```

#### 2.1.3 ASR识别流程

**使用的ASR服务**: 阿里云DashScope Paraformer-Realtime-V2  
**模型特点**: 原生支持中英文混合识别  
**文件**: [`asr_core.py`](../asr_core.py:1)

**启动识别**:
```python
# 1. 客户端发送START命令
await ws.send_text("START")

# 2. 服务器创建ASR识别实例 (app_main.py:1048-1056)
recognition = dash_audio.asr.Recognition(
    api_key=API_KEY,
    model="paraformer-realtime-v2",
    format="pcm",
    sample_rate=16000,
    callback=ASRCallback(...)
)
recognition.start()
```

**音频流传输**:
```python
# 3. 持续发送音频数据 (app_main.py:1081-1087)
while streaming:
    audio_chunk = await ws.receive_bytes()
    recognition.send_audio_frame(audio_chunk)
```

**识别结果回调** ([`asr_core.py`](../asr_core.py:215)):
```python
def _handle(self, event):
    # 提取识别文本
    text, is_end = _extract_sentence(event)
    
    # partial结果：仅用于UI展示
    if not is_end:
        await ui_broadcast_partial(text)
    
    # final结果：触发AI处理
    if is_end:
        await ui_broadcast_final(text)
        await start_ai_with_text(text)
```

#### 2.1.4 混合ASR支持（可选）

系统支持本地ASR+云端ASR的混合模式：
- **本地ASR**: 使用Whisper模型进行快速识别
- **云端验证**: 低置信度时使用云端ASR验证
- **配置**: 通过[`local_asr.py`](../local_asr.py)实现

---

### 2.2 文本处理与命令路由

#### 2.2.1 命令识别逻辑

**文件**: [`app_main.py`](../app_main.py:589)  
**函数**: `start_ai_with_text_custom(user_text: str)`

**处理流程**:
```python
async def start_ai_with_text_custom(user_text: str):
    # 1. 导航命令检测（关键字匹配）
    if "开始过马路" in user_text:
        orchestrator.start_crossing()
        play_voice_text("过马路模式已启动。")
        return
    
    if "开始导航" in user_text:
        orchestrator.start_blind_path_navigation()
        return
    
    # 2. 物品搜索命令
    match = re.search(r"找一下\s*(.+?)(?:。|$)", user_text)
    if match:
        item_name = match.group(1)
        start_yolomedia_with_target(item_name)
        return
    
    # 3. 其他文本 → 进入Qwen对话
    await start_ai_with_text(user_text)
```

**命令类型**:
1. **导航控制**: 开始过马路、盲道导航、停止导航
2. **红绿灯检测**: 检测红绿灯、停止检测
3. **物品搜索**: 帮我找xxx、找到了
4. **通用对话**: 其他所有文本

---

### 2.3 Qwen多模态对话

#### 2.3.1 对话触发

**文件**: [`app_main.py`](../app_main.py:775)  
**函数**: `start_ai_with_text(user_text: str)`

**关键步骤**:
```python
async def start_ai_with_text(user_text: str):
    # 1. 抓取当前视频帧（在设置标志前）
    captured_frame = None
    if last_frames:
        _, captured_frame = last_frames[-1]
    
    # 2. 设置对话标志，暂停导航
    omni_conversation_active = True
    if orchestrator:
        orchestrator.force_state("CHAT")
    
    # 3. 启动对话任务
    task = loop.create_task(_runner())
```

#### 2.3.2 多模态内容组装

**图像处理**:
```python
# 组装内容列表 (app_main.py:807-818)
content_list = []

# 添加图像（Base64编码）
if captured_frame:
    img_b64 = base64.b64encode(captured_frame).decode("ascii")
    content_list.append({
        "type": "image_url",
        "image_url": {"url": f"data:image/jpeg;base64,{img_b64}"}
    })

# 添加文本
content_list.append({"type": "text", "text": user_text})
```

#### 2.3.3 Qwen API调用

**文件**: [`omni_client.py`](../omni_client.py:69)  
**函数**: `stream_chat(content_list, voice, audio_format)`

**API配置**:
```python
# API设置 (omni_client.py:11-21)
API_KEY = os.getenv("DASHSCOPE_API_KEY")
QWEN_MODEL = "qwen-omni-turbo"

oai_client = OpenAI(
    api_key=API_KEY,
    base_url="https://dashscope.aliyuncs.com/compatible-mode/v1"
)
```

**流式调用**:
```python
# 创建流式对话 (omni_client.py:96-103)
completion = oai_client.chat.completions.create(
    model="qwen-omni-turbo",
    messages=[
        {"role": "system", "content": "系统提示+实时上下文"},
        {"role": "user", "content": content_list}
    ],
    modalities=["text", "audio"],
    audio={"voice": "Cherry", "format": "wav"},
    stream=True
)
```

**实时上下文增强** ([`omni_client.py`](../omni_client.py:29)):
```python
def get_realtime_context() -> str:
    # 1. 当前时间（年月日、星期、时段）
    # 2. 天气信息（通过wttr.in API获取）
    # 3. 地理位置
    return context_string
```

#### 2.3.4 流式响应处理

**返回数据格式**:
```python
class OmniStreamPiece:
    text_delta: Optional[str]   # 文本增量
    audio_b64: Optional[str]    # Base64编码的音频
```

**处理流程** ([`app_main.py`](../app_main.py:828)):
```python
async for piece in stream_chat(content_list):
    # 文本增量 → UI展示
    if piece.text_delta:
        txt_buf.append(piece.text_delta)
        await ui_broadcast_partial("[AI] " + "".join(txt_buf))
    
    # 音频分片 → 实时播放
    if piece.audio_b64:
        pcm24 = base64.b64decode(piece.audio_b64)
        # 降采样并播放
        await broadcast_pcm16_realtime(pcm24)
```

---

### 2.4 音频处理与下行传输

#### 2.4.1 音频格式转换

**Qwen返回格式**:
- 采样率: 24000 Hz
- 编码: PCM 16-bit
- 格式: WAV（Base64编码）

**ESP32需要格式**:
- 采样率: 8000 Hz
- 编码: PCM 16-bit
- 格式: WAV流

**转换过程** ([`app_main.py`](../app_main.py:838-848)):
```python
# 1. Base64解码
pcm24 = base64.b64decode(piece.audio_b64)

# 2. 降采样 24kHz → 8kHz（使用audioop.ratecv）
pcm8k, rate_state = audioop.ratecv(
    pcm24,      # 输入音频
    2,          # 采样宽度（16-bit = 2字节）
    1,          # 声道数
    24000,      # 输入采样率
    8000,       # 输出采样率
    rate_state  # 状态（保持音调）
)

# 3. 音量调节（降低到60%）
pcm8k = audioop.mul(pcm8k, 2, 0.60)

# 4. 实时分发
await broadcast_pcm16_realtime(pcm8k)
```

#### 2.4.2 实时音频分发

**文件**: [`audio_stream.py`](../audio_stream.py:79)  
**函数**: `broadcast_pcm16_realtime(pcm16: bytes)`

**分发策略**:
```python
async def broadcast_pcm16_realtime(pcm16: bytes):
    # 1. 按20ms分片
    BYTES_PER_20MS = 320  # 8kHz * 2字节 * 20ms
    
    # 2. 遍历所有连接的客户端
    for sc in stream_clients:
        # 3. 队列满时丢弃旧数据（保持实时性）
        if sc.q.full():
            sc.q.get_nowait()  # 丢弃最旧的
        
        # 4. 放入新数据
        sc.q.put_nowait(piece)
    
    # 5. 精确的20ms节拍控制
    await asyncio.sleep(0.020)
```

#### 2.4.3 HTTP音频流

**接口**: `/stream.wav`  
**协议**: HTTP GET（流式响应）  
**文件**: [`audio_stream.py`](../audio_stream.py:121)

**WAV流格式**:
```python
def _wav_header_unknown_size(sr=8000, ch=1, sw=2):
    # RIFF头 + fmt块 + data块
    # data_size设为最大值（流式传输）
    return wav_header_bytes
```

**流式生成器**:
```python
async def gen():
    # 1. 发送WAV头
    yield _wav_header_unknown_size(8000, 1, 2)
    
    # 2. 持续发送音频数据
    while True:
        chunk = await q.get()  # 从队列获取
        if chunk is None:      # None表示结束
            break
        yield chunk
```

**客户端连接**:
```javascript
// ESP32或浏览器
const audio = new Audio('https://server:8081/stream.wav');
audio.play();
```

---

## 三、关键技术点

### 3.1 音频采样率转换

**为什么需要转换**:
- Qwen输出: 24kHz（高质量）
- ESP32支持: 8kHz（硬件限制）

**转换方法**:
```python
# 使用audioop.ratecv保证音调不变
pcm_out, state = audioop.ratecv(
    pcm_in,     # 输入PCM数据
    2,          # 16-bit = 2字节
    1,          # 单声道
    24000,      # 输入采样率
    8000,       # 输出采样率
    state       # 保持状态（重要！）
)
```

**Python 3.13兼容性**:
- audioop模块在3.13中被移除
- 使用numpy实现兼容版本（[`app_main.py`](../app_main.py:79)）

### 3.2 实时性保证

**策略**:
1. **队列满丢尾**: 优先保证最新数据
2. **20ms精确节拍**: 使用asyncio.sleep精确控制
3. **非阻塞发送**: 队列满时立即丢弃旧数据

**代码示例**:
```python
# 队列满时的处理
if sc.q.full():
    try:
        sc.q.get_nowait()  # 丢弃最旧的数据
    except:
        pass
sc.q.put_nowait(new_data)  # 放入最新数据
```

### 3.3 打断机制

**热词打断** ([`asr_core.py`](../asr_core.py:164)):
```python
INTERRUPT_KEYWORDS = {"停下", "别说了", "停止"}

if self._has_hotword(text):
    # 立即全系统复位
    await full_system_reset("Hotword interrupt")
    return  # 不送入LLM
```

**新输入打断** ([`asr_core.py`](../asr_core.py:262)):
```python
if final_text:
    # 如果正在播放，先打断
    if self._is_playing():
        await self._full_reset("New input detected")
    
    # 启动新的AI任务
    await self._start_ai(final_text)
```

### 3.4 状态管理

**导航状态机** ([`navigation_master.py`](../navigation_master.py)):
```
IDLE → BLINDPATH_NAV → SEEKING_CROSSWALK → WAIT_TRAFFIC_LIGHT → CROSSING
  ↓                                                                    ↓
CHAT ←──────────────────────────────────────────────────────────────┘
  ↓
ITEM_SEARCH
```

**对话时的状态切换**:
```python
# 进入对话时
omni_previous_nav_state = orchestrator.get_state()
orchestrator.force_state("CHAT")

# 对话结束后
orchestrator.force_state(omni_previous_nav_state)
```

---

## 四、数据流总结

### 4.1 上行流程（用户 → AI）

```
麦克风 → ESP32 → WebSocket(/ws_audio) → ASR识别 → 文本
                  ↓                        ↓
              PCM 16kHz              paraformer-realtime-v2
              640字节/20ms            (阿里云DashScope)
                                          ↓
                                    识别文本 → 命令路由
                                          ↓
                                    ┌─────┴─────┐
                              导航命令      对话请求
                                ↓              ↓
                            预录音播放    Qwen多模态对话
```

### 4.2 下行流程（AI → 用户）

```
Qwen-Omni-Turbo → 流式返回 → 音频处理 → HTTP流 → ESP32 → 扬声器
      ↓              ↓           ↓          ↓
  文本+音频      Base64解码   降采样    /stream.wav
  (24kHz)        ↓           24k→8k     WAV格式
              PCM数据      音量调节    8kHz PCM
                          实时分发
```

### 4.3 文件格式汇总

| 阶段 | 格式 | 采样率 | 编码 | 传输方式 |
|------|------|--------|------|----------|
| ESP32上传 | PCM | 16kHz | 16-bit | WebSocket二进制 |
| ASR处理 | PCM | 16kHz | 16-bit | DashScope API |
| Qwen输出 | WAV | 24kHz | 16-bit | Base64字符串 |
| 服务器处理 | PCM | 8kHz | 16-bit | 内存队列 |
| ESP32下载 | WAV | 8kHz | 16-bit | HTTP流 |

---

## 五、性能优化

### 5.1 音频处理优化

1. **降采样优化**: 使用状态保持，避免音调变化
2. **音量预调节**: 统一降低到60%，避免爆音
3. **队列管理**: 小缓冲（96帧），快速响应

### 5.2 网络传输优化

1. **WebSocket复用**: 单连接持续传输
2. **HTTP流式**: 避免缓冲，实时播放
3. **帧差检测**: 视频传输时跳过相似帧

### 5.3 并发处理优化

1. **异步架构**: 全异步IO，避免阻塞
2. **线程池**: 模型推理使用独立线程池
3. **GPU加速**: 视频解码和模型推理使用GPU

---

## 六、错误处理

### 6.1 ASR错误

```python
def on_error(self, err):
    # 1. 清空UI显示
    await ui_broadcast_partial("")
    
    # 2. 通知错误
    self._on_sdk_error(str(err))
    
    # 3. 自动重启识别
    await ws.send_text("RESTART")
```

### 6.2 网络断线

```python
# WebSocket断线检测
if ws.client_state != WebSocketState.CONNECTED:
    break

# 清理资源
await stop_rec()
stream_clients.clear()
```

### 6.3 音频播放中断

```python
# 检测abort事件
if sc.abort_event.is_set():
    break

# 清理死连接
for sc in dead:
    stream_clients.discard(sc)
```

---

## 七、配置说明

### 7.1 环境变量

```bash
# .env文件
DASHSCOPE_API_KEY=sk-xxxxx        # 阿里云API密钥
ASR_LANGUAGE=auto                  # ASR语言（auto/zh/en）
INTERRUPT_KEYWORDS=停下,别说了     # 打断热词
ASR_DEBUG_RAW=0                    # ASR调试模式
```

### 7.2 音频参数

```python
# app_main.py
SAMPLE_RATE = 16000   # ASR采样率
CHUNK_MS = 20         # 音频分片大小

# audio_stream.py
STREAM_SR = 8000      # 下行采样率
STREAM_QUEUE_MAX = 96 # 队列大小
```

---

## 八、调试指南

### 8.1 启用调试日志

```python
# 设置环境变量
ASR_DEBUG_RAW=1

# 查看ASR原始事件
[ASR EVENT RAW] {"output": {"sentence": {"text": "你好"}}}
```

### 8.2 音频录制

系统自动录制所有音频到`recordings/`目录：
```python
# sync_recorder.py
sync_recorder.record_audio(pcm_data, text="[Omni对话]")
```

### 8.3 性能监控

```python
# 帧处理统计
if frame_counter % 30 == 0:
    print(f"[DEBUG] 帧:{frame_counter}, 状态:{state}")
```

---

## 九、常见问题

### Q1: 为什么音频有延迟？

**原因**: 队列积压  
**解决**: 减小`STREAM_QUEUE_MAX`，启用丢尾策略

### Q2: 音调变化怎么办？

**原因**: 降采样时未保持状态  
**解决**: 使用`audioop.ratecv`的state参数

### Q3: 如何支持更多语言？

**方法**: 修改ASR模型配置
```python
recognition = dash_audio.asr.Recognition(
    model="paraformer-realtime-v2",
    # 支持中英文混合，无需额外配置
)
```

### Q4: 如何提高识别准确率？

**方法**:
1. 使用混合ASR（本地+云端）
2. 添加热词词典
3. 优化麦克风音质

---

## 十、参考资料

### 10.1 相关文件

- [`app_main.py`](../app_main.py) - 主服务器
- [`asr_core.py`](../asr_core.py) - ASR核心逻辑
- [`omni_client.py`](../omni_client.py) - Qwen客户端
- [`audio_stream.py`](../audio_stream.py) - 音频流管理
- [`audio_player.py`](../audio_player.py) - 音频播放器

### 10.2 API文档

- [阿里云DashScope ASR](https://help.aliyun.com/zh/dashscope/developer-reference/api-details-9)
- [Qwen-Omni-Turbo](https://help.aliyun.com/zh/dashscope/developer-reference/qwen-omni-turbo)
- [OpenAI兼容接口](https://help.aliyun.com/zh/dashscope/developer-reference/compatibility-of-openai-with-dashscope)

### 10.3 技术栈

- **后端**: FastAPI + asyncio
- **ASR**: 阿里云Paraformer-Realtime-V2
- **LLM**: Qwen-Omni-Turbo（多模态）
- **音频**: audioop / numpy
- **通信**: WebSocket + HTTP Stream

---

## 附录：完整调用示例

### A.1 客户端上传音频

```javascript
// ESP32或浏览器
const ws = new WebSocket('wss://server:8081/ws_audio');

ws.onopen = () => {
    // 1. 发送START命令
    ws.send('START');
    
    // 2. 持续发送音频
    setInterval(() => {
        const audioChunk = recordAudio();  // 640字节
        ws.send(audioChunk);
    }, 20);
};

ws.onmessage = (event) => {
    console.log('服务器响应:', event.data);
    // OK:STARTED / RESTART / etc.
};
```

### A.2 服务器处理流程

```python
# 1. 接收音频
@app.websocket("/ws_audio")
async def ws_audio(ws: WebSocket):
    recognition = dash_audio.asr.Recognition(...)
    recognition.start()
    
    while True:
        audio_chunk = await ws.receive_bytes()
        recognition.send_audio_frame(audio_chunk)

# 2. ASR回调
class ASRCallback:
    def on_event(self, event):
        text = extract_text(event)
        await start_ai_with_text(text)

# 3. Qwen对话
async def start_ai_with_text(text):
    async for piece in stream_chat([text]):
        if piece.audio_b64:
            pcm = base64.b64decode(piece.audio_b64)
            await broadcast_pcm16_realtime(pcm)

# 4. 音频分发
async def broadcast_pcm16_realtime(pcm):
    for client in stream_clients:
        client.q.put_nowait(pcm)
```

### A.3 客户端播放音频

```javascript
// 浏览器
const audio = new Audio('https://server:8081/stream.wav');
audio.play();

// ESP32
http.begin("https://server:8081/stream.wav");
http.GET();
while (http.connected()) {
    uint8_t buffer[320];
    int len = http.getStream().readBytes(buffer, 320);
    i2s_write(buffer, len);
}
```

---

**文档版本**: v1.0  
**最后更新**: 2025-01-08  
**维护者**: AI眼镜项目组