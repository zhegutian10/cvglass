1.目标：
搭建一个盲人导航系统

2.实现方式：
2.1核心功能
2.1.1用本地的OpenCV实现基础实时图像逻辑
    用cv2调用摄像头传输图像，逐帧读取画面；再传给Yolo处理
2.1.2本地OpenCV/Yolo模型：
    1)前端按钮开启或关闭盲道导航功能后，返回“切换到盲道导航”/“导航已被取消”，实现盲道追踪，告诉用户“向左”、“向右”、“路径被挡住请向右侧平移”、“路径被挡住请向左侧平移”等提示，音频在\music文件夹下，匹配对应名称的wav文件名称。
    2)前端按钮开启或关闭红绿灯功能后，返回“过马路模式已启动”/“过马路模式已取消”，实现斑马线和红绿灯识别，告诉用户“远处发现斑马线”、“正在靠近斑马线”、“斑马线到了可以过马路”、“红灯”、“黄灯”、“绿灯”，音频在\music文件夹下，匹配对应名称的wav文件名称。
    3)通过语音命令(ASR识别+关键词提取+Qwen翻译成英文标签)开启找物体功能后，告诉用户物品位置，“在画面左侧”、“在画面右侧”、“在画面中间”、“拿到啦”，音频在\music文件夹下，匹配对应名称的wav文件名称。
2.1.3用通义千问的API实现功能交互（调用方式在下方，API-KEY在本地.env文件中）：如：
    1)语音识别：调用如通义千问ASR-Realtime，对手机话筒传输的语音进行识别返回到主机，关键词匹配的命令交由YOLO处理，通用问题由Qwen处理和回答
    2)物体识别：用户发出类似“前面有什么”、“这是什么”指令，提取帧图片后，向Qwen大模型发送，并将 “物体描述”通过ASR转换成文本和语音转换返回到手机。
    3)基础对话：调用大语言模型如Qwen进行日常对话，类似“几点了”，“今天怎么样”
    #注意：流式语音对话，一旦用户发出新指令，旧的对话语音等应该立即停止去响应新指令

3前端功能
3.1前端参考\mobile\index.html，保留现有功能，并接入上述模型

4.部署
    所有功能将通过docker部署到云服务器

4.其他注意事项：
    4.1优先调用独立GPU处理图像，本机为RTX5070TI,适合cuda版本为12.8
    4.2所有创建的.md放在\readme文件夹下
    4.3所有与主程序关联不大的测试程序放在\test文件夹下
    4.4设计一个监控程序放置在\monitor文件夹下，用来监测上传的视频、音频、文字状态信息
    4.5调用手机硬盘必须使用https访问，需要配置对应的服务器
    4.6模型文件放置于\models中，功能模块旋转于\modules中


附录一：opencv、大模型和Yolo如何协同作用
1. OpenCV 发挥什么作用？
OpenCV 在这个项目中是图像和视频处理的基石，几乎所有的视觉操作都离不开它。其主要作用包括：

图像解码：当视频流从 ESP32 摄像头通过 WebSocket 发送过来时，它们是 JPEG 格式的二进制数据。将这些数据解码成计算机可以处理的图像格式（NumPy 数组）。
图像预处理：在将图像送入 YOLO 或 MediaPipe 模型之前，通常需要进行预处理，例如调整尺寸 (cv2.resize()) 和转换颜色空间 (cv2.cvtColor()，例如从 BGR 转换为 RGB)，这些都是由 OpenCV 完成的。
图像后处理与可视化：
当 YOLO 模型返回识别结果（如边界框、掩码）后，OpenCV 负责将这些信息绘制在视频画面上，例如画出物体的轮廓 (cv2.drawContours())、矩形框 (cv2.rectangle())、中心点 (cv2.circle()) 以及引导文字 (cv2.putText())。
创建半透明的掩码叠加效果 (cv2.addWeighted()) 也依赖 OpenCV。
高级视觉算法：在 yolo 的追踪模式中，使用了更高级的 OpenCV 功能：
特征点检测：使用 cv2.goodFeaturesToTrack() 在物体边缘上寻找适合追踪的关键点。
光流追踪：使用 cv2.calcOpticalFlowPyrLK() 在连续的视频帧之间追踪这些特征点的运动，从而在不重新运行 YOLO 的情况下预测物体的位置，实现流畅的追踪效果。

2. Qwen和ASR 作用
2.1 Qwen处理开放式问题
当您提出一个开放性问题时（例如，“帮我看看前面是什么”、“这个牌子上写的什么字”），系统会执行以下操作：
它会捕获当前原始的视频画面 (一个未经处理的 JPEG 图像) 和您问题的文本。
这两样东西（图像 + 文本）被一起发送给 Qwen 的多模态大模型 (omni 模型)。
Qwen 理解图像和文本，并生成语音回复。
在这个流程中，YOLO 完全没有参与。Qwen 直接分析原始图像来回答问题。因此，凭借其强大的多模态能力，Qwen 可以识别图像中的人像、文字、物体以及复杂的场景。

2.2传递语音指令给YOLO
第一步：语音转文字 (ASR)
用户的语音通过麦克风输入后，在 /ws_audio 接口中，被发送给阿里云的 Paraformer ASR (Automatic Speech Recognition) 模型，而不是 Qwen。
这个专业的 ASR 模型负责将音频流实时转换成文本字符串，例如，将您的语音 “开始盲道导航” 转换成文字 "开始盲道导航"。

第二步：文本解析与意图识别
ASR 返回的文本被送到判定指令的函数中。
1)对于导航指令，未来的目标是通过语音命令实现 (如ASR识别 "开始盲道导航","过马路模式"，"红绿灯")：系统使用非常简单的关键字匹配 (if "开始导航" in user_text:) 以及前端对应按钮，来识别意图。这部分逻辑是硬编码的，没有使用 Qwen（它首先检查用户的指令是否是预设的、需要快速反应的导航命令。如果是，就立即通过代码逻辑调用相应的功能模块（这些模块依赖 YOLO）。只有当指令不匹配任何关键字时，系统才会认为这是一个开放性问题，并将其交给 Qwen 进行理解和回答。）。
匹配成功后，直接调用导航功能来启动对应的 YOLO 导航模块。
*但是重要的事项：目前我们只需要实现接收前端UI的“过马路功能”和“盲道导航”的两个按钮状态来决定是否启用对应的功能。
2)对于寻物指令 (如 "帮我找一下红牛"，"找红牛"，"红牛在哪里")：
使用非常简单的关键字匹配识别意图，然后用正则表达式从ASR返回的文本中提取出物品名称 "红牛"。
再将中文名 "红牛" 发送给 Qwen翻译，要求其转换成一个简短的英文 YOLO 类别名，得到 "Red_Bull"。
最后，系统启动 yolo 模块，并将 "Red_Bull" 作为目标传给其中的 YOLO 模型去执行识别。
Qwen如何识别类似任务：如果收到类似“找一下”的语音，则发送如下提示词，并返回最可能的英文物品名称。PROMPT：(
    "You are a label normalizer. Convert the given Chinese object "
    "description into a short, lowercase English YOLO/vision class name "
    "(1~3 words). If multiple are given, return the single most likely one. "
    "Output ONLY the label, no punctuation."
)

3. YOLO 作用(暂未涉及)
当您发出特定指令时（例如，“开始盲道导航”或“帮我找一下红牛”），系统会使用 YOLO 模型进行实时、高效的识别：
导航任务：使用 yolov8s-seg.pt 模型来分割识别盲道、斑马线等，并结合障碍物检测模型来生成导航指令（例如“向左平移”）。这些语音是预先录制好的，由 audio_player.py 播放。
红绿灯导航任务；使用 yolov8s-seg.pt 模型识别红绿灯状态，回复语音等待或者可以通行。
寻找物品任务：
当您说“帮我找红牛”时，qwen_extractor.py 中的 extract_english_label() 函数会先被调用。它可能会使用 Qwen 将中文“红牛”转换为 YOLO 模型能识别的英文标签 "Red_Bull"。
然后，系统启动 yolomedia.py 模块，并告诉它的 YOLO 模型去专门寻找带有 "Red_Bull" 标签的物体。
这个流程中，Qwen 只是在任务开始前做了一次“翻译”，帮助 YOLO 确定目标，YOLO 的识别结果（如位置、掩码）并不会再传回给 Qwen。

附录二：调用通义千问的API的方式如下：
安装完成Python以及DashScope的Python SDK，可以参考以下步骤发送您的API请求。
import os
from dashscope import Generation
import dashscope 

messages = [
    {'role': 'system', 'content': 'You are a helpful assistant.'},
    {'role': 'user', 'content': '你是谁？'}
    ]
response = Generation.call(
    # 若没有配置环境变量，请用阿里云百炼API Key将下行替换为：api_key = "sk-xxx",
    api_key=os.getenv("DASHSCOPE_API_KEY"), 
    model="qwen-plus",   # 模型列表：https://help.aliyun.com/zh/model-studio/getting-started/models
    messages=messages,
    result_format="message"
)

if response.status_code == 200:
    print(response.output.choices[0].message.content)
else:
    print(f"HTTP返回码：{response.status_code}")
    print(f"错误码：{response.code}")
    print(f"错误信息：{response.message}")
    print("请参考文档：https://help.aliyun.com/zh/model-studio/developer-reference/error-code")

附录三：调用ASR-Realtime方法
import logging
import os
import base64
import signal
import sys
import time
import dashscope
from dashscope.audio.qwen_omni import *
from dashscope.audio.qwen_omni.omni_realtime import TranscriptionParams


def setup_logging():
    """配置日志输出"""
    logger = logging.getLogger('dashscope')
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.propagate = False
    return logger


def init_api_key():
    """初始化 API Key"""
    # 新加坡和北京地域的API Key不同。获取API Key：https://help.aliyun.com/zh/model-studio/get-api-key
    # 若没有配置环境变量，请用百炼API Key将下行替换为：dashscope.api_key = "sk-xxx"
    dashscope.api_key = os.environ.get('DASHSCOPE_API_KEY', 'YOUR_API_KEY')
    if dashscope.api_key == 'YOUR_API_KEY':
        print('[Warning] Using placeholder API key, set DASHSCOPE_API_KEY environment variable.')


class MyCallback(OmniRealtimeCallback):
    """实时识别回调处理"""
    def __init__(self, conversation):
        self.conversation = conversation
        self.handlers = {
            'session.created': self._handle_session_created,
            'conversation.item.input_audio_transcription.completed': self._handle_final_text,
            'conversation.item.input_audio_transcription.text': self._handle_stash_text,
            'input_audio_buffer.speech_started': lambda r: print('======Speech Start======'),
            'input_audio_buffer.speech_stopped': lambda r: print('======Speech Stop======'),
            'response.done': self._handle_response_done
        }

    def on_open(self):
        print('Connection opened')

    def on_close(self, code, msg):
        print(f'Connection closed, code: {code}, msg: {msg}')

    def on_event(self, response):
        try:
            handler = self.handlers.get(response['type'])
            if handler:
                handler(response)
        except Exception as e:
            print(f'[Error] {e}')

    def _handle_session_created(self, response):
        print(f"Start session: {response['session']['id']}")

    def _handle_final_text(self, response):
        print(f"Final recognized text: {response['transcript']}")

    def _handle_stash_text(self, response):
        print(f"Got stash result: {response['stash']}")

    def _handle_response_done(self, response):
        print('======RESPONSE DONE======')
        print(f"[Metric] response: {self.conversation.get_last_response_id()}, "
              f"first text delay: {self.conversation.get_last_first_text_delay()}, "
              f"first audio delay: {self.conversation.get_last_first_audio_delay()}")


def read_audio_chunks(file_path, chunk_size=3200):
    """按块读取音频文件"""
    with open(file_path, 'rb') as f:
        while chunk := f.read(chunk_size):
            yield chunk


def send_audio(conversation, file_path, delay=0.1):
    """发送音频数据"""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Audio file {file_path} does not exist.")

    print("Processing audio file... Press 'Ctrl+C' to stop.")
    for chunk in read_audio_chunks(file_path):
        audio_b64 = base64.b64encode(chunk).decode('ascii')
        conversation.append_audio(audio_b64)
        time.sleep(delay)
    # enable_turn_detection为False时，应将下行代码注释取消
    # conversation.commit()
    # print("Audio commit sent.")

def send_silence_data(conversation, cycles=30, bytes_per_cycle=1024):
    # 创建1024字节的静音数据（全零）
    silence_data = bytes(bytes_per_cycle)

    for i in range(cycles):
        # 将字节数据编码为base64
        audio_b64 = base64.b64encode(silence_data).decode('ascii')
        # 发送静音数据
        conversation.append_audio(audio_b64)
        time.sleep(0.01)  # 10毫秒延迟
    print(f"已发送 {cycles} 次静音数据，每次 {bytes_per_cycle} 字节")

def main():
    setup_logging()
    init_api_key()

    audio_file_path = "./your_audio_file.pcm"
    conversation = OmniRealtimeConversation(
        model='qwen3-asr-flash-realtime',
        # 以下为北京地域url，若使用新加坡地域的模型，需将url替换为：wss://dashscope-intl.aliyuncs.com/api-ws/v1/realtime
        url='wss://dashscope.aliyuncs.com/api-ws/v1/realtime',
        callback=MyCallback(conversation=None)  # 暂时传None，稍后注入
    )

    # 注入自身到回调
    conversation.callback.conversation = conversation

    def handle_exit(sig, frame):
        print('Ctrl+C pressed, exiting...')
        conversation.close()
        sys.exit(0)

    signal.signal(signal.SIGINT, handle_exit)

    conversation.connect()

    transcription_params = TranscriptionParams(
        language='zh',
        sample_rate=16000,
        input_audio_format="pcm"
        # 输入音频的语料，用于辅助识别
        # corpus_text=""
    )

    conversation.update_session(
        output_modalities=[MultiModality.TEXT],
        enable_input_audio_transcription=True,
        transcription_params=transcription_params
    )

    try:
        send_audio(conversation, audio_file_path)
        # 追加发送静音音频，防止音频文件尾部没有静音导致无法判停
        send_silence_data(conversation)
        time.sleep(3)  # 等待响应
    except Exception as e:
        print(f"Error occurred: {e}")
    finally:
        conversation.close()
        print("Audio processing completed.")


if __name__ == '__main__':
    main()