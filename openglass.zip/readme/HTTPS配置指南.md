# HTTPS配置指南

## 🔒 为什么需要HTTPS？

移动端浏览器（iOS Safari、Android Chrome等）出于安全考虑，**必须使用HTTPS才能访问摄像头和麦克风**。

使用HTTP访问时：
- ❌ 摄像头无法启动
- ❌ 麦克风无法录音
- ❌ 浏览器会阻止媒体设备访问

使用HTTPS访问时：
- ✅ 摄像头正常工作
- ✅ 麦克风正常录音
- ✅ 所有功能可用

---

## 🚀 快速配置（3步完成）

### 步骤1: 生成SSL证书

```bash
# 确保已激活虚拟环境
.venv\Scripts\activate

# 安装证书生成依赖
pip install pyopenssl

# 运行证书生成脚本
python generate_cert.py
```

**成功输出：**
```
============================================================
AI盲人眼镜系统 - SSL 证书生成工具
============================================================

[证书生成] 使用 PyOpenSSL 生成证书...
[成功] 证书已生成:
  - cert.pem (证书文件)
  - key.pem (私钥文件)

[完成] 证书生成成功！
============================================================
```

### 步骤2: 启动HTTPS服务器

```bash
# 启动服务器（自动检测并使用HTTPS）
python main.py

# 应该看到:
# 🔒 启动HTTPS服务器...
# INFO:     Uvicorn running on https://0.0.0.0:8001
```

### 步骤3: 移动端访问

```bash
# 1. 获取服务器IP地址
ipconfig  # Windows
ifconfig  # Linux/Mac

# 2. 在手机浏览器访问
https://192.168.1.100:8001
# (替换为你的实际IP地址)

# 3. 接受证书警告
# 点击"高级" → "继续访问"
```

---

## 📱 不同平台的配置方法

### Android (Chrome/Firefox)

1. 在浏览器输入：`https://服务器IP:8001`
2. 看到"您的连接不是私密连接"警告
3. 点击 **"高级"**
4. 点击 **"继续访问(不安全)"**
5. ✅ 完成！现在可以使用摄像头和麦克风

**截图示例：**
```
┌─────────────────────────────────┐
│  您的连接不是私密连接            │
│                                  │
│  攻击者可能会试图窃取您的信息    │
│                                  │
│  [返回安全页面]  [高级]          │
└─────────────────────────────────┘
         ↓ 点击"高级"
┌─────────────────────────────────┐
│  此服务器无法证明它是...         │
│                                  │
│  [继续访问 192.168.1.100(不安全)]│
└─────────────────────────────────┘
         ↓ 点击继续访问
         ✅ 成功访问
```

### iOS (Safari)

iOS对证书要求更严格，需要额外步骤：

#### 方法1: 手动信任证书（推荐）

1. **访问网站**
   - 在Safari输入：`https://服务器IP:8001`
   - 看到"此连接不是私密连接"

2. **下载证书**
   - 点击"显示详细信息"
   - 点击"访问此网站"
   - 或直接访问：`https://服务器IP:8001/cert.pem`

3. **安装描述文件**
   - 前往：设置 → 通用 → VPN与设备管理
   - 找到下载的描述文件
   - 点击"安装"
   - 输入密码确认

4. **启用证书信任**
   - 前往：设置 → 通用 → 关于本机
   - 滚动到底部，点击"证书信任设置"
   - 找到刚安装的证书
   - 开启"启用完全信任"开关
   - 点击"继续"确认

5. **重新访问网站**
   - 返回Safari
   - 刷新页面
   - ✅ 现在可以正常使用

#### 方法2: 使用mkcert（更简单）

```bash
# 在服务器上安装mkcert
# Windows
choco install mkcert

# Mac
brew install mkcert

# Linux
wget https://github.com/FiloSottile/mkcert/releases/download/v1.4.4/mkcert-v1.4.4-linux-amd64
chmod +x mkcert-v1.4.4-linux-amd64
sudo mv mkcert-v1.4.4-linux-amd64 /usr/local/bin/mkcert

# 安装本地CA
mkcert -install

# 生成证书（替换为你的IP）
mkcert localhost 192.168.1.100 *.local

# 重命名文件
mv localhost+2.pem cert.pem
mv localhost+2-key.pem key.pem

# 重启服务器
python main.py
```

使用mkcert生成的证书，iOS会自动信任，无需手动配置。

### Windows/Mac/Linux 桌面浏览器

#### Chrome/Edge
1. 访问 `https://localhost:8001`
2. 看到"您的连接不是私密连接"
3. 点击"高级"
4. 点击"继续前往 localhost(不安全)"
5. ✅ 完成

#### Firefox
1. 访问 `https://localhost:8001`
2. 看到"警告：潜在的安全风险"
3. 点击"高级"
4. 点击"接受风险并继续"
5. ✅ 完成

#### Safari (Mac)
1. 访问 `https://localhost:8001`
2. 看到"此连接不是私密连接"
3. 点击"显示详细信息"
4. 点击"访问此网站"
5. ✅ 完成

---

## 🔧 证书生成脚本说明

[`generate_cert.py`](../generate_cert.py) 会自动选择最佳方式生成证书：

### 生成内容

- **cert.pem**: SSL证书文件（公钥）
- **key.pem**: 私钥文件（保密）

### 证书特性

- **加密强度**: RSA 4096位
- **有效期**: 1年（365天）
- **签名算法**: SHA-256
- **支持域名**: 
  - localhost
  - *.local
  - 127.0.0.1
  - 0.0.0.0
  - 可自定义添加更多

### 自定义配置

如需添加更多IP或域名，编辑 `generate_cert.py` 第72行：

```python
cert.add_extensions([
    crypto.X509Extension(
        b"subjectAltName",
        False,
        b"DNS:localhost,DNS:*.local,IP:127.0.0.1,IP:192.168.1.100,IP:10.0.0.5"
        # ↑ 在这里添加你的IP地址
    ),
])
```

---

## 🐛 常见问题

### Q1: 证书生成失败，提示"未安装pyOpenSSL"

**解决方案：**
```bash
pip install pyopenssl
```

### Q2: iOS Safari仍然无法访问摄像头

**检查清单：**
- [ ] 确认使用HTTPS访问（地址栏有🔒图标）
- [ ] 确认已在"证书信任设置"中启用信任
- [ ] 尝试重启Safari（双击Home键关闭Safari）
- [ ] 尝试重启iPhone
- [ ] 检查Safari设置 → 隐私与安全性 → 摄像头权限

**终极解决方案：**
使用mkcert生成证书（见上文方法2）

### Q3: 证书过期了怎么办？

**解决方案：**
```bash
# 删除旧证书
del cert.pem key.pem  # Windows
rm cert.pem key.pem   # Linux/Mac

# 重新生成
python generate_cert.py

# 重启服务器
python main.py
```

### Q4: 浏览器一直显示"不安全"

这是正常的！自签名证书会显示警告，但不影响使用。

**原因：**
- 证书不是由受信任的CA签发
- 浏览器无法验证证书的真实性

**解决方案：**
- 开发环境：忽略警告，点击"继续访问"
- 生产环境：使用Let's Encrypt或购买商业证书

### Q5: 如何在局域网内其他设备访问？

**步骤：**
1. 确保所有设备在同一WiFi网络
2. 获取服务器IP地址：
   ```bash
   ipconfig  # Windows
   ifconfig  # Linux/Mac
   ```
3. 在其他设备访问：
   ```
   https://服务器IP:8001/mobile/index.html
   ```
4. 接受证书警告

### Q6: 使用内网穿透工具（ngrok）

如果需要从外网访问，可以使用ngrok：

```bash
# 下载ngrok: https://ngrok.com/download

# 启动隧道
ngrok http 8001

# ngrok会提供一个HTTPS地址，例如:
# https://abc123.ngrok.io

# 直接使用这个地址访问，无需配置证书
```

**优点：**
- 自动提供HTTPS
- 无需配置证书
- 可从任何地方访问

**缺点：**
- 需要网络连接
- 免费版有限制
- 地址每次重启会变化

---

## 🏭 生产环境证书

开发环境使用自签名证书即可，但生产环境建议使用正式证书。

### 选项1: Let's Encrypt（免费，推荐）

```bash
# 安装certbot
sudo apt-get install certbot

# 获取证书（需要域名）
sudo certbot certonly --standalone -d yourdomain.com

# 证书位置
# /etc/letsencrypt/live/yourdomain.com/fullchain.pem
# /etc/letsencrypt/live/yourdomain.com/privkey.pem

# 在main.py中使用
ssl_certfile="/etc/letsencrypt/live/yourdomain.com/fullchain.pem"
ssl_keyfile="/etc/letsencrypt/live/yourdomain.com/privkey.pem"
```

### 选项2: 云服务商证书

- **阿里云**: 免费SSL证书（1年）
- **腾讯云**: 免费SSL证书（1年）
- **AWS**: Certificate Manager（免费）

### 选项3: 商业证书

- DigiCert
- GlobalSign
- Comodo

---

## 🔐 安全建议

### 开发环境
- ✅ 使用自签名证书
- ✅ 证书有效期1年即可
- ✅ 可以忽略浏览器警告

### 生产环境
- ✅ 使用Let's Encrypt或商业证书
- ✅ 定期更新证书（Let's Encrypt 90天）
- ✅ 配置自动续期
- ✅ 使用强加密套件

### 私钥保护
```bash
# 设置私钥文件权限（Linux/Mac）
chmod 600 key.pem

# 不要将私钥提交到Git
echo "key.pem" >> .gitignore
echo "cert.pem" >> .gitignore
```

### 证书验证
```bash
# 查看证书信息
openssl x509 -in cert.pem -text -noout

# 验证证书和私钥匹配
openssl x509 -noout -modulus -in cert.pem | openssl md5
openssl rsa -noout -modulus -in key.pem | openssl md5
# 两个MD5值应该相同

# 测试HTTPS连接
curl -k https://localhost:8001
```

---

## 📚 相关文档

- [完整开发指南](开发指南.md)
- [快速参考](快速参考.md)
- [项目介绍](../intro.md)

---

## 🆘 需要帮助？

如果遇到问题：
1. 查看本文档的"常见问题"部分
2. 检查服务器日志
3. 验证证书文件是否存在
4. 确认防火墙设置

---

**版本**: 1.0.0  
**最后更新**: 2025-11-04  
**维护者**: 开发团队